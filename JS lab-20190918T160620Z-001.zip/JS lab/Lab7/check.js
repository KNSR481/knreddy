
 function formit(){
    var barb = document.getElementById("bab").value;
    var calc = document.getElementById("cal").value;
    var mob = document.getElementById("mobile").value;
    var dvd = document.getElementById("dvd").value;
     localStorage.setItem("barb",barb)
     localStorage.setItem("calc",calc)
     localStorage.setItem("mob",mob)
     localStorage.setItem("dvd",dvd)
       if(barb!="" || calc!=="" || mob!=="" || dvd!==""){
        window.open('C:/Users/Abridge Solutions/Documents/rohan sahu/lab6/invoice.html','Newwindows','toolbar=no,status=no,width=500,height=200');
       }
       else{
        
        alert("No item Selected");
       };

       
   }
//    var barbie = document.getElementById("bab").value;
//     var calca = document.getElementById("cal").value;
//     var mobi = document.getElementById("mobile").value;
//     var dvdlg = document.getElementById("dvd").value;


   
   

