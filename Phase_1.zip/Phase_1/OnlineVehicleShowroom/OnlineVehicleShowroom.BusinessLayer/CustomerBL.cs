﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;
using System.Text.RegularExpressions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class CustomerBL
    {
    
        // VAlidations for customer.....

        private static bool validateCustomer(Customer customer)
        {
            StringBuilder sb = new StringBuilder();
            bool validCustomer = true;

            if ( customer.CustomerID <=0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Invalid Customer ID it should be greater than 0");
            }
            if (customer.CustomerID.ToString()== string.Empty)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Id is Required");
            }
            if (customer.CustomerName == string.Empty)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Name is Required");
            }
            if(Regex.IsMatch(customer.CustomerName, "[a-zA-Z]{30}$"))
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Name have only alphebets");
            }
            if (customer.ContactNo.Length != 10)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Required 10 digit Contact Number");
            }
            if (customer.ContactNo == string.Empty)

            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Contact Number cannot be empty");
            }
            if(customer.Gender!="male" && customer.Gender!="female" && customer.Gender!="others" )
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer gender is invalid");
            }

            if (Convert.ToString(customer.Pincode).Length < 6)
            {
                validCustomer = false;

                sb.Append(Environment.NewLine + "Customer Pincode must be of 6 digit");
            }
            if (customer.Pincode.ToString() == string.Empty)

            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Pincode cannot be empty");
            }
            if (customer.City == string.Empty)

            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "city field cannot be empty");
            }

            if (customer.State == string.Empty)

            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "state field cannot be empty");
            }
            if (customer.Address == string.Empty)

            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Address field cannot be empty");
            }

            if (customer.Email == string.Empty)

            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Email field cannot be empty");
            }

            if (!Regex.Match(customer.Email.ToString(), "[a-z0-9]*@[a-z]*.com$").Success)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Email Should be in correct formate");
            }

            if (validCustomer == false)

                throw new OVSRException(sb.ToString());

            return validCustomer;
        }

        //Add Customer Data

        public static bool AddCustomerBL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
             if(validateCustomer(newCustomer))
                {
                    CustomerDAL customerDAL = new CustomerDAL();
                    customerAdded = customerDAL.AddCustomerDAL(newCustomer);
                }

            }
            catch (OVSRException message)
            {

                throw message;
            }
            catch (Exception e)
            {
                throw e;
            }

            return customerAdded;
        }

        //Get all Customer Details

        public static List<Customer> GetAllCustomersBL()
        {
            List<Customer> customerList = null;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();
                customerList = customerDAL.GetAllCustomerDAL();
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customerList;
        }

        //search Customer Data.....

        public static Customer SearchCustomerBL(int searchCustomerID)
        {
            Customer searchCustomer = null;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();
                searchCustomer = customerDAL.SearchCustomerDAL(searchCustomerID);
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCustomer;

        }

        //Update Customer .......

        public static bool UpdateCustomerBL(Customer updateCustomer)
        {
            bool customerUpdated = false;
            try
            {
                if (validateCustomer(updateCustomer))
                {
                    CustomerDAL customerDAL = new CustomerDAL();
                    customerUpdated = customerDAL.UpdateCustomerDAL(updateCustomer);
                }
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return customerUpdated;
        }
    }
}
