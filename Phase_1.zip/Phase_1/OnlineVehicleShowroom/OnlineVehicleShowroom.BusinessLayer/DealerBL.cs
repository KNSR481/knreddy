﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;
using System.Text.RegularExpressions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class DealerBL
    {
        //Validation Part

        private static bool validateDealer(Dealer dealer)
        {
            StringBuilder sb = new StringBuilder();
            bool validDealer = true;


            if (dealer.DealerID <= 0)
            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Invalid Dealer ID it should be greater than 0");
            }
            if (dealer.DealerID.ToString() == string.Empty)
            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Dealer ID is Required");
            }
            if (dealer.DealerName == string.Empty)
            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Dealer Name is Required");
            }
            if (Regex.IsMatch(dealer.DealerName, "[a-zA-Z]{30}$"))
            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Dealer Name have only alphebets");
            }
            if (dealer.ContactNo.Length != 10)
            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Required 10 digit Contact Number");
            }
            if (dealer.ContactNo == string.Empty)
            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Contact number is Required");
            }
            if (Convert.ToString(dealer.Pincode).Length < 6)
            {
                validDealer = false;

                sb.Append(Environment.NewLine + "Dealer Pincode must be of 6 digit");
            }
            if (dealer.Pincode.ToString() == string.Empty)
            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Pincode  is Required");
            }
            if (dealer.City == string.Empty)

            {
                validDealer = false;
                sb.Append(Environment.NewLine + "city field cannot be empty");
            }

            if (dealer.State == string.Empty)

            {
                validDealer = false;
                sb.Append(Environment.NewLine + "state field cannot be empty");
            }
            if (dealer.Address == string.Empty)

            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Address field cannot be empty");
            }

            if (dealer.CompanyName == string.Empty)
            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Company Name is Required");
            }
            if (Regex.IsMatch(dealer.CompanyName, "[a-zA-Z]{30}$"))
            {
                validDealer = false;
                sb.Append(Environment.NewLine + "Company Name have only alphebets");
            }

            if (validDealer == false)
            {
                throw new OVSRException(sb.ToString());
            }

            return validDealer;
        }

        //Add Dealer..

        public static bool AddDealerBL(Dealer newDealer)
        {
            bool DealerAdded = false;
            try
            {
                if (validateDealer(newDealer))
                {
                    DealerDAL dealerDAL = new DealerDAL();
                    DealerAdded = dealerDAL.AddDealerDAL(newDealer);
                }

            }
            catch (OVSRException message)
            {

                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return DealerAdded;
        }

        //Get all Dealers

        public static List<Dealer> GetAllDealersBL()
        {
            List<Dealer> dealerList = null;
            try
            {
                DealerDAL dealerDAL = new DealerDAL();
                dealerList = dealerDAL.GetAllDealerDAL();
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dealerList;
        }


    }
}
