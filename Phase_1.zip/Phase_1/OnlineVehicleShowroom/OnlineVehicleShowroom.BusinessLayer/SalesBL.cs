﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class SalesBL
    {
        //Validation Part.......

        private static bool validateSales(Sales sales)
        {
            StringBuilder sb = new StringBuilder();
            bool validSales = true;

            if (sales.SalesID <= 0)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Invalid Vehicle ID it should be Greater than 0");
            }
            if (sales.SalesID.ToString() == string.Empty)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Vehicle Id is Required");
            }
            if (sales.VehicleID <= 0)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Invalid Vehicle ID it should be Greater than 0");
            }
            if (sales.VehicleID.ToString() == string.Empty)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Vehicle Id is Required");
            }

            if (sales.CustomerID <= 0)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Invalid Customer ID it should be greater than 0");
            }
            if (sales.CustomerID.ToString() == string.Empty)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Customer Id is Required");
            }
            if (sales.ShowroomID <= 0)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Invalid Showrrom ID it should be Greater than 0");
            }
            if (sales.ShowroomID.ToString() == string.Empty)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Showroom Id is Required");
            }

            if (sales.Cost.ToString() == string.Empty)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Vehicle Cost is Required");
            }
            if (sales.Remarks == string.Empty)
            {
                validSales = false;
                sb.Append(Environment.NewLine + "Remarks is Required");
            }
           
            if (validSales == false)
            {
                throw new OVSRException(sb.ToString());
            }

            return validSales;
        }

        //Add sales Data

        public static bool AddSalesBL(Sales newSales)
        {
            bool SalesAdded = false;
            try
            {
                if (validateSales(newSales))
                {
                    SalesDAL salesDAL = new SalesDAL();
                    SalesAdded = salesDAL.AddSalesDAL(newSales);
                }

            }
            catch (OVSRException message)
            {

                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return SalesAdded;
        }

        //Get all sales data..

        public static List<Sales> GetAllSalesBL()
        {
            List<Sales> salesList = null;
            try
            {
                SalesDAL salesDAL = new SalesDAL();
                salesList = salesDAL.GetAllSalesDAL();
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return salesList;
        }

        //Generate Bill

        public static Sales GenerateBillBL(int newBill)
        {
            Sales bill = null;
            try
            {
                SalesDAL billDAL = new SalesDAL();
                bill = billDAL.GenerateBillDAL(newBill);
            }
            catch(OVSRException message)
            {
                throw message;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return bill;
        }
    }
}
