﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;
using System.Text.RegularExpressions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class ShowroomBL
    {
        //Validation Part

        private static bool validateShowroom(Showroom showroom)
        {
            StringBuilder sb = new StringBuilder();
            bool validShowroom = true;

            if (showroom.ShowroomID <= 0)
            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Invalid Showrrom ID it should be Greater than 0");
            }
            if (showroom.ShowroomID.ToString() == string.Empty)
            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Showroom Id is Required");
            }
            if (showroom.ShowroomName == string.Empty)
            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Showroom Name is Required");
            }
            if (Regex.IsMatch(showroom.ShowroomName, "[a-zA-Z]{30}$"))
            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Vehicle Name have only alphebets");
            }
            if (showroom.DealerID <= 0)
            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Invalid Dealer ID it should be greater than 0");
            }
            if (showroom.DealerID.ToString() == string.Empty)
            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Dealer ID is Required");
            }

            if (showroom.OwnerName == string.Empty)
            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Owner Name is Required");
            }
            if (Regex.IsMatch(showroom.OwnerName, "[a-zA-Z]{30}$"))
            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Owner Name have only alphebets");
            }
            if (showroom.ContactNo.Length != 10)
            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Required 10 digit Contact Number");
            }
            if (showroom.ContactNo == string.Empty)

            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Contact Number cannot be empty");
            }

            if (Convert.ToString(showroom.Pincode).Length < 6)
            {
                validShowroom = false;

                sb.Append(Environment.NewLine + " Pincode must be of 6 digit");
            }

            if (showroom.City == string.Empty)

            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "city field cannot be empty");
            }

            if (showroom.State == string.Empty)

            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "state field cannot be empty");
            }
            if (showroom.Address == string.Empty)

            {
                validShowroom = false;
                sb.Append(Environment.NewLine + "Address field cannot be empty");
            }

            if (validShowroom == false)
            {
                throw new OVSRException(sb.ToString());
            }

            return validShowroom;
        }

        //Add Showroom Data......

        public static bool AddShowroomBL(Showroom newShowroom)
        {
            bool ShowroomAdded = false;
            try
            {
                if (validateShowroom(newShowroom))
                {
                    ShowroomDAL showroomDAL = new ShowroomDAL();
                    ShowroomAdded = showroomDAL.AddShowroomDAL(newShowroom);
                }

            }
            catch (OVSRException message)
            {

                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ShowroomAdded;
        }

        //Get All Showroom Details...

        public static List<Showroom> GetAllShowroomBL()
        {
            List<Showroom> showroomList = null;
            try
            {
                ShowroomDAL showroomDAL = new ShowroomDAL();
                showroomList = showroomDAL.GetAllShowroomDAL();
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return showroomList;
        }
    }
}
