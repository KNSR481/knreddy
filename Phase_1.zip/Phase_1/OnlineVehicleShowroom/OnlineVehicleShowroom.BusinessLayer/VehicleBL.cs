﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;
using System.Text.RegularExpressions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class VehicleBL
    {
        //Validation Part......

        private static bool validateVehicle(Vehicle vehicle)
        {
            StringBuilder sb = new StringBuilder();
            bool validVehicle = true;

            if (vehicle.VehicleID <= 0)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Invalid Vehicle ID it should be Greater than 0");
            }
            if (vehicle.VehicleID.ToString() == string.Empty)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Vehicle Id is Required");
            }
            if (vehicle.VehicleName == string.Empty)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Vehicle Name is Required");
            }
            if (Regex.IsMatch(vehicle.VehicleName, "[a-zA-Z]{30}$"))
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Vehicle Name have only alphebets");
            }

            if (vehicle.VehicleModel == string.Empty)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Vehicle Model is Required");
            }

            if (vehicle.DealerID <= 0)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Invalid Dealer ID it should be greater than 0");
            }
            if (vehicle.DealerID.ToString() == string.Empty)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Dealer ID is Required");
            }
            if (vehicle.Cost.ToString() == string.Empty)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Vehicle Cost is Required");
            }

            if (vehicle.TotalStock.ToString() == string.Empty)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Total stock is Required");
            }
            if (vehicle.Description == string.Empty)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Description  is Required");
            }
            if (vehicle.Rating.ToString() == string.Empty)
            {
                validVehicle = false;
                sb.Append(Environment.NewLine + "Vehicle Rating is Required");
            }

            if (validVehicle == false)
            {
                throw new OVSRException(sb.ToString());
            }

            return validVehicle;
        }

        //Add Vehicle
        public static bool AddVehicleBL(Vehicle newvehicle)
        {
            bool vehicleAdded = false;
            try
            {
                if (validateVehicle(newvehicle))
                {
                    VehicleDAL vehicleDAL = new VehicleDAL();
                    vehicleAdded = vehicleDAL.AddVehicleDAL(newvehicle);
                }

            }
            catch (OVSRException message)
            {

                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return vehicleAdded;
        }

        //List All Vehicles.............
        public static List<Vehicle> GetAllVehicleBL()
        {
            List<Vehicle> vehicleList = null;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                vehicleList = vehicleDAL.GetAllVehicleDAL();
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return vehicleList;
        }

        //Vehicle Search By ID.....................
        public static Vehicle SearchVehicleByIdBL(int searchVehicleID)
        {
            Vehicle searchVehicle = null;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                searchVehicle = vehicleDAL.SearchVehicleByIdDAL(searchVehicleID);
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVehicle;

        }

        //Vehicle Search By Name..................
        public static Vehicle SearchVehicleByNameBL(string searchVehicleName)
        {
            Vehicle searchVehicle = null;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                searchVehicle = vehicleDAL.SearchVehicleByNameDAL(searchVehicleName);
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVehicle;

        }

        //Vehicle Search By Model................

        public static Vehicle SearchVehicleByModelBL(string searchVehicleModel)
        {
            Vehicle searchVehicle = null;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                searchVehicle = vehicleDAL.SearchVehicleByModelDAL(searchVehicleModel);
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVehicle;

        }

        //Update Vehicle........
        public static bool UpdateVehicleBL(Vehicle updateVehicle)
        {
            bool vehicleUpdated = false;
            try
            {
                if (validateVehicle(updateVehicle))
                {
                    VehicleDAL vehicleDAL = new VehicleDAL();
                    vehicleUpdated = vehicleDAL.UpdateVehicleDAL(updateVehicle);
                }
            }
            catch (OVSRException message)
            {
                throw message;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return vehicleUpdated;
        }
    }
}
