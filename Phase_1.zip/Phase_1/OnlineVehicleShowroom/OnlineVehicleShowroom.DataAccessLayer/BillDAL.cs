﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using OnlineVehicleShowroom.Entities;
//using OnlineVehicleShowroom.Exceptions;

//namespace OnlineVehicleShowroom.DataAccessLayer
//{
//    public class BillDAL
//    {
//        Bill objbill;
//        //Vehicle objVehicle;
//        //public List<Sales> Sales
//        //{
//        //    get
//        //    {
//        //        return SalesDAL.salesList;
//        //    }
//        //}
//        //public List<Vehicle> Vehicle
//        //{
//        //    get
//        //    {
//        //        return VehicleDAL.vehicleList;
//        //    }
//        //}
//        public Bill GenerateBillDAL(int salesID)
//        {
//            Bill bill = null;
//            try
//            {
//                objbill = Sales.Find(sale => sale.SalesID == salesID);
//                //objVehicle = Vehicle.Find(vehicle => vehicle.VehicleID == vehicleID);
//                bill.BillID = new Random().Next();
//                bill.SalesID = objbill.SalesID;
//                bill.VehicleID = objbill.VehicleID;
//                bill.CustomerID = objbill.CustomerID;
//                bill.ShowroomID = objbill.ShowroomID;
//                bill.OrderDate = objbill.OrderDate;
//                bill.DeliveryDate = objbill.DeliveryDate;
//                bill.Cost = objbill.Cost;
//               // bill.TotalStock = objVehicle.TotalStock;

//            }
//            catch(SystemException ex)
//            {
//                throw new OVSRException(ex.Message);
//            }
//            return bill;
//        }
//        //public Bill GeneratePurchaseDAL(int salesID, int vehicleID)
//        //{
//        //    Bill bill = null;
//        //    try
//        //    {
//        //        objSale = Sales.Find(sale => sale.SalesID == salesID);
//        //        objVehicle = Vehicle.Find(vehicle => vehicle.VehicleID == vehicleID);
//        //        bill.BillID = new Random().Next();
//        //        bill.SalesID = objSale.SalesID;
//        //        bill.VehicleID = objSale.VehicleID;
//        //        bill.ShowroomID = objSale.ShowroomID;
//        //        bill.OrderDate = objSale.OrderDate;
//        //        bill.DeliveryDate = objSale.DeliveryDate;
//        //        bill.Cost = objSale.Cost;
//        //        bill.TotalStock = objVehicle.TotalStock;

//        //    }
//        //    catch (SystemException ex)
//        //    {
//        //        throw new OVSRException(ex.Message);
//        //    }
//        //    return bill;
//        //}
//    }
//}
