﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;


namespace OnlineVehicleShowroom.DataAccessLayer
{
    public class CustomerDAL
    {
        public static List<Customer> customerList = new List<Customer>();

        //Add Customer DAl....

        public bool AddCustomerDAL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
                customerList.Add(newCustomer);               
                customerAdded = true;

            }
            catch (SystemException ex)
            {

                throw new OVSRException(ex.Message);
            }
            return customerAdded;
        }

        //Search Customer By ID........

        public Customer SearchCustomerDAL(int searchCustomerID)
        {
            Customer searchCustomer = null;
            try
            {
                searchCustomer = customerList.Find(customer => customer.CustomerID == searchCustomerID);
            }
            catch (SystemException ex)
            {

                throw new OVSRException(ex.Message);
            }
            return searchCustomer;
        }

        //Update Customer......

        public  bool UpdateCustomerDAL(Customer updateCustomer)
        {
            bool customerUpdated = false;
            try
            {
                for(int i=0;i<customerList.Count;i++)
                {
                    updateCustomer.CustomerName = customerList[i].CustomerName;
                  
                    updateCustomer.Gender = customerList[i].Gender;
                    updateCustomer.ContactNo= customerList[i].ContactNo;
                    updateCustomer.Address = customerList[i].Address;
                    updateCustomer.City = customerList[i].City;
                    updateCustomer.State = customerList[i].State;
                    updateCustomer.Pincode = customerList[i].Pincode;
                    customerUpdated = true;



                }
            }
            catch (SystemException ex)
            {

                throw new OVSRException(ex.Message);
            }
            return customerUpdated;
        }

        //List All Customers...........

        public List<Customer> GetAllCustomerDAL()
        {
            return customerList;
        }

    }
}
