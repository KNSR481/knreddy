﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.DataAccessLayer
{
    public class SalesDAL
    {
        public static List<Sales> salesList = new List<Sales>();

        //Get All Sales Data......

        public List<Sales> GetAllSalesDAL()
        {
            return salesList;
        }

        //Add Sales data......

        public bool AddSalesDAL(Sales newSales)
        {
            bool SalesAdded = false;
            try
            {
                salesList.Add(newSales);            

                SalesAdded = true;
            }
            catch (SystemException e)
            {
                throw new OVSRException(e.Message);
            }
            return SalesAdded;
        }

        //Generate Bill.............

        public Sales GenerateBillDAL(int salesID)
        {
            Sales bill = null;
            try
            {
                Sales sales = new Sales();
                sales = salesList.Find(find => find.SalesID == salesID);

                if(sales!=null)
                {
                    bill = new Sales();
                    bill.SalesID = sales.SalesID;
                    bill.VehicleID = sales.VehicleID;
                    bill.CustomerID = sales.CustomerID;
                    bill.ShowroomID = sales.ShowroomID;
                    bill.OrderDate = sales.OrderDate;
                    bill.DeliveryDate = sales.DeliveryDate;
                    bill.Cost = sales.Cost;

                }
                else
                {
                    Console.WriteLine("bill not generated");
                }
            }
            catch(SystemException ex)
            {
                throw new OverflowException(ex.Message);
            }
            return bill;
        }

    }
}
