﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineVehicleShowroom.Entities
{
  public class Dealer
    {
        private int dealerID;
        private string dealerName;
        private string companyName;
        private string address;
        private string contactNo;
        private string city;
        private string state;
        private int pincode;

        public int DealerID { get; set; }
        public string DealerName { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string ContactNo { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int Pincode { get; set; }








    }
}
