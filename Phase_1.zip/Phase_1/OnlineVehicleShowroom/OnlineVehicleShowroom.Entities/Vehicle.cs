﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineVehicleShowroom.Entities
{
    public class Vehicle
    {
        private int vehicleID;
        private string vehicleName;
        private string vehicleModel;
        private int dealerID;
        private double cost;
        private int totalStock;
        private string description;
        private int rating;

        public int VehicleID { get; set; }
        public string VehicleName { get; set; }
        public string VehicleModel { get; set; }
        public int DealerID { get; set; }
        public double Cost { get; set; }
        public int TotalStock { get; set; }
        public string Description { get; set; }
        public int Rating { get; set; }

    }
}
