﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using OVSR.DataAccessLayer;


namespace OVSR.BusinessLayer
{
    public class BillBL
    {
       //Get all Sales Data for Sales ID..............

        public static List<Sales> GetAllSalesBL()
        {
            List<Sales> salesList;
            try
            {
                SalesDAL salesDAL = new SalesDAL();
                salesList = salesDAL.GetAllSalesDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return salesList;
        }

        //Generate Bill...........

        public static Bill GenerateBillBL(int SalesID)
        {
            Bill objBill = null;
            try
            {
                BillDAL billDAL = new BillDAL();
                objBill = billDAL.GenerateBillDAL(SalesID);
            }
            catch (OVSRException ex)
            {
                throw ex;
            }

            return objBill;

        }

        //Get all Bills Data................

        public static List<Bill> GetAllBillsBL()
        {
            List<Bill> billList = null;
            try
            {
                BillDAL billDAL = new BillDAL();
                billList = billDAL.GetAllBillsDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            return billList;
        }

        //Add Bill Data...............

        public static bool AddBillBL(Bill newBill)
        {
            bool billAdded = false;
            try
            { 
                BillDAL billDAL = new BillDAL();
                billAdded = billDAL.AddBillDAL(newBill);              
            }
            catch (OVSRException)
            {
                throw;
            }
            return billAdded;
        }

        //Search Method for Purchase Data..............

        public static Bill SearchPurchaseBL(int billID)
        {
            Bill bill = null;
            try
            {
                if (billID > 0)
                {
                    BillDAL billDAL = new BillDAL();
                    bill = billDAL.SearchPurchaseDAL(billID);
                }
                else
                {
                    throw new OVSRException("Bill Id must be greater than 0.");
                }
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bill;
        }


    }
}
