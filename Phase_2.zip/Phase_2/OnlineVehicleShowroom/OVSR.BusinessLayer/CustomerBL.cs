﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using OVSR.DataAccessLayer;


namespace OVSR.BusinessLayer
{
    public class CustomerBL
    {
        //Add Customer

        public static bool AddCustomerBL(Customer customer)
        {
            bool customerAdded = false;
            try
            {
                //if (ValidateCustomer(employee))
                //{
                    CustomerDAL customerDAL = new CustomerDAL();
                    customerAdded = customerDAL.AddCustomerDAL(customer);
                    return customerAdded;
                //}
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customerAdded;
        }
        
        //Update customer

        public static bool UpdateCustomerBL(Customer customer)
        {
            bool customerUpdated = false;
            try
            {
                //if (ValidateEmployee(employee))
                //{
                    CustomerDAL customerDAL = new CustomerDAL();
                customerUpdated = customerDAL.UpdateCustomerDAL(customer);
                    return customerUpdated;
                //}
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customerUpdated;
        }

        //Get All customers

        public static List<Customer> GetAllCustomersBL()
        {
            List<Customer> customerList;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();
                customerList = customerDAL.GetAllCustomersDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customerList;
        }

        //Search Customer

        public static Customer SearchCustomerBL(int customerId)
        {
            Customer customer = null;
            try
            {
                if (customerId > 0)
                {
                    CustomerDAL customerDAL = new CustomerDAL();
                    customer = customerDAL.SearchCustomerDAL(customerId);
                }
                else
                {
                    throw new OVSRException("customer Id must be greater than 0.");
                }
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customer;
        }

    }
}
