﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using OVSR.DataAccessLayer;

namespace OVSR.BusinessLayer
{
    public class DealerBL
    {
        //Add Dealer

        public static bool AddDealerBL(Dealer dealer)
        {
            bool dealerAdded = false;
            try
            {
                //if (ValidateCustomer(employee))
                //{
                DealerDAL dealerDAL = new DealerDAL();
                dealerAdded = dealerDAL.AddDealerDAL(dealer);
                return dealerAdded;
                //}
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dealerAdded;
        }

        //Get All Dealers

        public static List<Dealer> GetAllDealersBL()
        {
            List<Dealer> dealerList;
            try
            {
                DealerDAL dealerDAL = new DealerDAL();
                dealerList = dealerDAL.GetAllDealersDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dealerList;
        }

    }
}
