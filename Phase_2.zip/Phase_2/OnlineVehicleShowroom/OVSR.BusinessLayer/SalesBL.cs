﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using OVSR.DataAccessLayer;

namespace OVSR.BusinessLayer
{
    public class SalesBL
    {
        //Add Sales.............

        public static bool AddSalesBL(Sales sale)
        {
            bool saleAdded = false;
            try
            {
                //if (ValidateCustomer(employee))
                //{
                SalesDAL saleDAL = new SalesDAL();
                saleAdded = saleDAL.AddSalesDAL(sale);
                return saleAdded;
                //}
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return saleAdded;
        }

        //Get All Sales..............

        public static List<Sales> GetAllSalesBL()
        {
            List<Sales> salesList;
            try
            {
                SalesDAL saleDAL = new SalesDAL();
                salesList = saleDAL.GetAllSalesDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return salesList;
        }

        //Get all vehicles for Vehicle ID.....

        public static List<Vehicle> GetAllVehiclesBL()
        {
            List<Vehicle> vehicleList;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                vehicleList = vehicleDAL.GetAllVehicleDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return vehicleList;
        }

        //Get all Showrooms for Showroom ID...

        public static List<Showroom> GetAllShowroomsBL()
        {
            List<Showroom> showroomList;
            try
            {
                ShowroomDAL showroomDAL = new ShowroomDAL();
                showroomList = showroomDAL.GetAllShowroomDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return showroomList;
        }

        //Get all Customers For Customer ID................

        public static List<Customer> GetAllCustomersBL()
        {
            List<Customer> customerList;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();
                customerList = customerDAL.GetAllCustomersDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customerList;
        }

    }
}
