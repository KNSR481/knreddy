﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using OVSR.DataAccessLayer;



namespace OVSR.BusinessLayer
{
    public class ShowroomBL
    {
        //Add Showroom.....

        public static bool AddShowroomBL(Showroom showroom)
        {
            bool showroomAdded = false;
            try
            {
                //if (ValidateCustomer(employee))
                //{
                ShowroomDAL showroomDAL = new ShowroomDAL();
                showroomAdded = showroomDAL.AddShowroomDAL(showroom);
                return showroomAdded;
                //}
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return showroomAdded;
        }

        //Get All Showroom Data......

        public static List<Showroom> GetAllShowroomsBL()
        {
            List<Showroom> showroomList;
            try
            {
                ShowroomDAL showroomDAL = new ShowroomDAL();
                showroomList = showroomDAL.GetAllShowroomDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return showroomList;
        }

        //Get All Dealers for Dealeer ID..............

        public static List<Dealer> GetAllDealersBL()
        {
            List<Dealer> dealerList;
            try
            {
                DealerDAL dealerDAL = new DealerDAL();
                dealerList = dealerDAL.GetAllDealersDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dealerList;
        }

    }
}
