﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using OVSR.DataAccessLayer;

namespace OVSR.BusinessLayer
{
    public class VehicleBL
    {
        //Add Vehicle Data.........

        public static bool AddVehicleBL(Vehicle vehicle)
        {
            bool vehicleAdded = false;
            try
            {
                //if (ValidateCustomer(employee))
                //{
                VehicleDAL vehicleDAL = new VehicleDAL();
                vehicleAdded = vehicleDAL.AddVehicleDAL(vehicle);
                return vehicleAdded;
                //}
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return vehicleAdded;
        }

        //Update Vehicle.............

        public static bool UpdateVehicleBL(Vehicle vehicle)
        {
            bool vehicleUpdated = false;
            try
            {
                //if (ValidateEmployee(employee))
                //{
                VehicleDAL vehicleDAL = new VehicleDAL();
                vehicleUpdated = vehicleDAL.UpdateVehicleDAL(vehicle);
                return vehicleUpdated;
                //}
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return vehicleUpdated;
        }

        //Get All Vehicles Data.................

        public static List<Vehicle> GetAllVehiclesBL()
        {
            List<Vehicle> vehicleList;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                vehicleList = vehicleDAL.GetAllVehicleDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return vehicleList;
        }

        //Search Vehicle By ID..........

        public static Vehicle SearchVehicleByIdBL(int vehicleId)
        {
            Vehicle vehicle = null;
            try
            {
                //if (vehicleId > 0)
                //{
                    VehicleDAL vehicleDAl = new VehicleDAL();
                    vehicle = vehicleDAl.SearchVehicleDAL(vehicleId);
                //}
                //else
                //{
                //    throw new OVSRException("vehicle Id must be greater than 0.");
                //}
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            return vehicle;
        }

        //Get All Dealers for Dealer ID.............

        public static List<Dealer> GetAllDealersBL()
        {
            List<Dealer> dealerList;
            try
            {
                DealerDAL dealerDAL = new DealerDAL();
                dealerList = dealerDAL.GetAllDealersDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dealerList;
        }
    }
}
