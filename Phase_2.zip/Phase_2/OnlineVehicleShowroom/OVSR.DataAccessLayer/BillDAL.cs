﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace OVSR.DataAccessLayer
{
    public class BillDAL
    {
      
        SqlConnection objCon = null;

        //Generate bill.............

        public Bill GenerateBillDAL(int id)
        {
            Bill objBill = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCmd = new SqlCommand("[ar177501].USP_GenerateBill", objCon);
                objCmd.CommandType = CommandType.StoredProcedure;

                //Sql parameters                

                SqlParameter objSqlParam_ID = new SqlParameter("@salesid", SqlDbType.Int);
                SqlParameter objSqlParam_VehicleId = new SqlParameter("@vehicleid", SqlDbType.Int);
                SqlParameter objSqlParam_CustomerName = new SqlParameter("@customername", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_ShowroomId = new SqlParameter("@showroomid", SqlDbType.Int);
                SqlParameter objSqlParam_Cost = new SqlParameter("@cost", SqlDbType.Int);
                SqlParameter objSqlParam_OrderDate = new SqlParameter("@orderdate", SqlDbType.DateTime);
                SqlParameter objSqlParam_DeliveryDate = new SqlParameter("@deliverydate", SqlDbType.DateTime);

                //Sql command paremeters

                objSqlParam_ID.Direction = ParameterDirection.Input;
                objSqlParam_VehicleId.Direction = ParameterDirection.Output;
                objSqlParam_CustomerName.Direction = ParameterDirection.Output;
                objSqlParam_ShowroomId.Direction = ParameterDirection.Output;
                objSqlParam_Cost.Direction = ParameterDirection.Output;
                objSqlParam_OrderDate.Direction = ParameterDirection.Output;
                objSqlParam_DeliveryDate.Direction = ParameterDirection.Output;

                //Assigning of values

                objCmd.Parameters.Add(objSqlParam_ID);
                objCmd.Parameters.Add(objSqlParam_VehicleId);
                objCmd.Parameters.Add(objSqlParam_CustomerName);
                objCmd.Parameters.Add(objSqlParam_ShowroomId);
                objCmd.Parameters.Add(objSqlParam_Cost);
                objCmd.Parameters.Add(objSqlParam_OrderDate);
                objCmd.Parameters.Add(objSqlParam_DeliveryDate);

                objSqlParam_ID.Value = id;
                //
                objCon.Open();
                objCmd.ExecuteNonQuery();
                objBill = new Bill();
                objBill.SalesID = id;
                objBill.VehicleID = Convert.ToInt32(objSqlParam_VehicleId.Value);
                objBill.CustomerName = objSqlParam_CustomerName.Value.ToString();
                objBill.ShowroomID = Convert.ToInt32(objSqlParam_ShowroomId.Value);
                objBill.Cost = Convert.ToInt32(objSqlParam_Cost.Value);
                objBill.OrderDate = Convert.ToDateTime(objSqlParam_OrderDate.Value);
                objBill.DeliveryDate = Convert.ToDateTime(objSqlParam_DeliveryDate.Value);

            }
            catch (SqlException ex)
            {
                throw new OVSRException(ex.Message);
            }
            return objBill;
        }

        //Search Purchase Data..............

        public Bill SearchPurchaseDAL(int BillID)
        {
            Bill objBill = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].PurchaseData", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //Sql parameters

                SqlParameter objSqlParam_BillID = new SqlParameter("@billID", SqlDbType.Int);
                SqlParameter objSqlParam_SID = new SqlParameter("@salesid", SqlDbType.Int);
                SqlParameter objSqlParam_VehicleId = new SqlParameter("@vehicleid", SqlDbType.Int);
                SqlParameter objSqlParam_CustomerName = new SqlParameter("@customername", SqlDbType.VarChar, 100);
                SqlParameter objSqlParam_ShowroomId = new SqlParameter("@showroomid", SqlDbType.Int);
                SqlParameter objSqlParam_Cost = new SqlParameter("@cost", SqlDbType.Int);
                SqlParameter objSqlParam_OrderDate = new SqlParameter("@orderdate", SqlDbType.DateTime);
                SqlParameter objSqlParam_DeliveryDate = new SqlParameter("@deliverydate", SqlDbType.DateTime);
                SqlParameter objSqlParam_Quantity = new SqlParameter("@quantity", SqlDbType.Int);

                SqlParameter objSqlParam_billexists = new SqlParameter("@billexists", SqlDbType.Int);

                //Sql Command parameters.....

                objSqlParam_BillID.Direction = ParameterDirection.Input;
                objSqlParam_SID.Direction = ParameterDirection.Output;
                objSqlParam_VehicleId.Direction = ParameterDirection.Output;
                objSqlParam_CustomerName.Direction = ParameterDirection.Output;
                objSqlParam_ShowroomId.Direction = ParameterDirection.Output;
                objSqlParam_Cost.Direction = ParameterDirection.Output;
                objSqlParam_OrderDate.Direction = ParameterDirection.Output;
                objSqlParam_DeliveryDate.Direction = ParameterDirection.Output;
                objSqlParam_Quantity.Direction = ParameterDirection.Output;
                objSqlParam_billexists.Direction = ParameterDirection.Output;

                //Assigning of values.....

                objCom.Parameters.Add(objSqlParam_BillID);
                objCom.Parameters.Add(objSqlParam_SID);
                objCom.Parameters.Add(objSqlParam_VehicleId);
                objCom.Parameters.Add(objSqlParam_CustomerName);
                objCom.Parameters.Add(objSqlParam_ShowroomId);
                objCom.Parameters.Add(objSqlParam_Cost);
                objCom.Parameters.Add(objSqlParam_OrderDate);
                objCom.Parameters.Add(objSqlParam_DeliveryDate);
                objCom.Parameters.Add(objSqlParam_Quantity);
                objCom.Parameters.Add(objSqlParam_billexists);
                //
                objSqlParam_BillID.Value = BillID;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objBill = new Bill();
                objBill.BillID = BillID;

                if (Convert.ToInt32(objSqlParam_billexists.Value) == 1)
                {
                    objBill.SalesID = Convert.ToInt32(objSqlParam_SID.Value);
                    objBill.VehicleID = Convert.ToInt32(objSqlParam_VehicleId.Value);
                    objBill.CustomerName = objSqlParam_CustomerName.Value as string;
                    objBill.ShowroomID =Convert.ToInt32 (objSqlParam_ShowroomId.Value);
                    objBill.Cost =Convert.ToInt32 (objSqlParam_Cost.Value);
                    objBill.OrderDate = Convert.ToDateTime(objSqlParam_OrderDate.Value);
                    objBill.DeliveryDate =Convert.ToDateTime (objSqlParam_DeliveryDate.Value );
                    objBill.Quantity = Convert.ToInt32(objSqlParam_Quantity.Value);
                }
                else if (Convert.ToInt32(objSqlParam_billexists.Value) == 2)
                {
                    return null;
                }

            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objBill;
        }

        //Get all Bills Data................

        public List<Bill> GetAllBillsDAL()
        {
            List<Bill> objBill = new List<Bill>();
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCmd = new SqlCommand("[ar177501].GetAllBill", objCon);
                objCmd.CommandType = CommandType.StoredProcedure;

                objCon.Open();
                SqlDataReader objDR = objCmd.ExecuteReader();
                while (objDR.Read())
                {
                    Bill objBills = new Bill();
                    objBills.BillID = Convert.ToInt32(objDR[0]);
                    objBills.SalesID = Convert.ToInt32(objDR[1]);
                    objBills.Quantity = Convert.ToInt32(objDR[2]);
                    objBills.VehicleID = Convert.ToInt32(objDR[3]);
                    objBills.CustomerName = objDR[4] as string;
                    objBills.ShowroomID = Convert.ToInt32(objDR[5]);
                    objBills.Cost = Convert.ToInt32(objDR[6]);
                    objBills.OrderDate = Convert.ToDateTime(objDR[7]);
                    objBills.DeliveryDate = Convert.ToDateTime(objDR[8]);
                    objBill.Add(objBills);
                }
            }
            catch (SqlException objEx)
            {

                throw new OVSRException(objEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objBill;
        }

        //Add Bill Data..............

        public bool AddBillDAL(Bill newBill)
        {
            bool billAdded = false;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCmd = new SqlCommand("[ar177501].AddBill", objCon);
                objCmd.CommandType = CommandType.StoredProcedure;

                //Sql parameters

                SqlParameter objSqlParam_SalesId = new SqlParameter("@salesid", newBill.SalesID);
                SqlParameter objSqlParam_Quantity = new SqlParameter("@quantity", newBill.Quantity);
                SqlParameter objSqlParam_VehicleId = new SqlParameter("@vehicleid", newBill.VehicleID);
                SqlParameter objSqlParam_CustomerId = new SqlParameter("@customername", newBill.CustomerName);
                SqlParameter objSqlParam_ShowroomId = new SqlParameter("@showroomid", newBill.ShowroomID);
                SqlParameter objSqlParam_Cost = new SqlParameter("@cost", newBill.Cost);
                SqlParameter objSqlParam_OrderDate = new SqlParameter("@orderdate", newBill.OrderDate);
                SqlParameter objSqlParam_DeliveryDate = new SqlParameter("@deliverydate", newBill.DeliveryDate);


                //Sql Command Parameters

                objCmd.Parameters.Add(objSqlParam_SalesId);
                objCmd.Parameters.Add(objSqlParam_Quantity);
                objCmd.Parameters.Add(objSqlParam_VehicleId);
                objCmd.Parameters.Add(objSqlParam_CustomerId);
                objCmd.Parameters.Add(objSqlParam_ShowroomId);
                objCmd.Parameters.Add(objSqlParam_Cost);
                objCmd.Parameters.Add(objSqlParam_OrderDate);
                objCmd.Parameters.Add(objSqlParam_DeliveryDate);

                objCon.Open();
                objCmd.ExecuteNonQuery();
                billAdded = true;

            }
            catch (SqlException objex)
            {
                throw new OVSRException(objex.Message);
            }
            return billAdded;
        }

        //List All Sales foer Sales ID....................

        public List<Sales> GetAllSalesDAL()
        {
            List<Sales> objSales = new List<Sales>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllSales", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Sales objsales = new Sales();

                    objsales.SalesID = Convert.ToInt32(objDR[0]);
                    objsales.VehicleID = Convert.ToInt32(objDR[1]);
                    objsales.CustomerID = Convert.ToInt32(objDR[2]);
                    objsales.ShowroomID = Convert.ToInt32(objDR[3]);
                    objsales.Cost = Convert.ToInt32(objDR[4]);
                    objsales.OrderDate = Convert.ToDateTime(objDR[5]);
                    objsales.DeliveryDate = Convert.ToDateTime(objDR[6]);
                    objsales.Remarks = objDR[7] as string;
                    objSales.Add(objsales);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objSales;
        }

    }
}
