﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace OVSR.DataAccessLayer
{
    public class CustomerDAL
    {
        //Add Customer...........

        public bool AddCustomerDAL(Customer objCustomer)
        {
            bool customerAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_AddCustomer", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //Sql Parameters........

                SqlParameter objSqlParam_ID = new SqlParameter("@CustomerID", objCustomer.CustomerID);
                SqlParameter objSqlParam_Name = new SqlParameter("@CustomerName", objCustomer.CustomerName);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objCustomer.Gender);
                SqlParameter objSqlParam_CNO = new SqlParameter("@ContactNO", objCustomer.ContactNo);
                SqlParameter objSqlParam_Email = new SqlParameter("@Email", objCustomer.Email);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", objCustomer.Address);
                SqlParameter objSqlParam_City = new SqlParameter("@City", objCustomer.City);
                SqlParameter objSqlParam_State = new SqlParameter("@State", objCustomer.State);
                SqlParameter objSqlParam_Pincode = new SqlParameter("@Pincode", objCustomer.Pincode);

                //Assigning of values............

                objCom.Parameters.Add(objSqlParam_ID);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Gender);
                objCom.Parameters.Add(objSqlParam_CNO);
                objCom.Parameters.Add(objSqlParam_Email);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_City);
                objCom.Parameters.Add(objSqlParam_State);
                objCom.Parameters.Add(objSqlParam_Pincode);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                customerAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return customerAdded;
        }

        //Update Customer............

        public bool UpdateCustomerDAL(Customer objCustomer)
        {
            bool customerUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_UpdateCustomer", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //sql command paramerts

                SqlParameter objSqlParam_ID = new SqlParameter("@CustomerID", objCustomer.CustomerID);
                SqlParameter objSqlParam_Name = new SqlParameter("@CustomerName", objCustomer.CustomerName);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objCustomer.Gender);
                SqlParameter objSqlParam_CNO = new SqlParameter("@ContactNO", objCustomer.ContactNo);
                SqlParameter objSqlParam_Email = new SqlParameter("@Email", objCustomer.Email);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", objCustomer.Address);
                SqlParameter objSqlParam_City = new SqlParameter("@City", objCustomer.City);
                SqlParameter objSqlParam_State = new SqlParameter("@State", objCustomer.State);
                SqlParameter objSqlParam_Pincode = new SqlParameter("@Pincode", objCustomer.Pincode);

                //Assigning of values..........

                objCom.Parameters.Add(objSqlParam_ID);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Gender);
                objCom.Parameters.Add(objSqlParam_CNO);
                objCom.Parameters.Add(objSqlParam_Email);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_City);
                objCom.Parameters.Add(objSqlParam_State);
                objCom.Parameters.Add(objSqlParam_Pincode);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                customerUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return customerUpdated;
        }

        //Search Customer.............

        public Customer SearchCustomerDAL(int CustomerID)
        {
            Customer objCustomer = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].SearchCustomerByID", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //Sql parameters..........

                SqlParameter objSqlParam_Id = new SqlParameter("@customerID", SqlDbType.Int);
                SqlParameter objSqlParam_Name = new SqlParameter("@customerName", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Gender = new SqlParameter("@gender", SqlDbType.VarChar,30);
                SqlParameter objSqlParam_CNO = new SqlParameter("@contactNO", SqlDbType.VarChar,30);
                SqlParameter objSqlParam_Email = new SqlParameter("@email", SqlDbType.VarChar,30);
                SqlParameter objSqlParam_Address = new SqlParameter("@address", SqlDbType.VarChar, 30);
                SqlParameter objSqlParam_City = new SqlParameter("@city", SqlDbType.VarChar, 30);
                SqlParameter objSqlParam_State = new SqlParameter("@state", SqlDbType.VarChar, 30);
                SqlParameter objSqlParam_Pincode = new SqlParameter("@pincode", SqlDbType.Int);
                SqlParameter objSqlParam_customerexists = new SqlParameter("@customerexists", SqlDbType.Int);

                //Sql command Parameters.

                objSqlParam_Id.Direction = ParameterDirection.Input;
                objSqlParam_Name.Direction = ParameterDirection.Output;
                objSqlParam_Gender.Direction = ParameterDirection.Output;
                objSqlParam_CNO.Direction = ParameterDirection.Output;
                objSqlParam_Email.Direction = ParameterDirection.Output;
                objSqlParam_Address.Direction = ParameterDirection.Output;
                objSqlParam_City.Direction = ParameterDirection.Output;
                objSqlParam_State.Direction = ParameterDirection.Output;
                objSqlParam_Pincode.Direction = ParameterDirection.Output;
                objSqlParam_customerexists.Direction = ParameterDirection.Output;

                //Assigning of values..............

                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Gender);
                objCom.Parameters.Add(objSqlParam_CNO);
                objCom.Parameters.Add(objSqlParam_Email);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_City);
                objCom.Parameters.Add(objSqlParam_State);
                objCom.Parameters.Add(objSqlParam_Pincode);
                objCom.Parameters.Add(objSqlParam_customerexists);
                //
                objSqlParam_Id.Value = CustomerID;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objCustomer = new Customer();
                objCustomer.CustomerID = CustomerID;

                if(Convert.ToInt32(objSqlParam_customerexists.Value) == 1)
                {
                    objCustomer.CustomerName = objSqlParam_Name.Value as string;
                    objCustomer.Gender = objSqlParam_Gender.Value as string; ;
                    objCustomer.ContactNo = objSqlParam_CNO.Value as string;
                    objCustomer.Email = objSqlParam_Email.Value as string;
                    objCustomer.Address = objSqlParam_Address.Value as string;
                    objCustomer.City = objSqlParam_City.Value as string;
                    objCustomer.State = objSqlParam_State.Value as string;
                    objCustomer.Pincode = Convert.ToInt32(objSqlParam_Pincode.Value);
                }
                else if (Convert.ToInt32(objSqlParam_customerexists.Value) == 2)
                {
                    return null;
                }

            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCustomer;
        }

        //Get all Customers Data................

        public List<Customer> GetAllCustomersDAL()
        {
            List<Customer> objCustomers = new List<Customer>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllCustomers", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Customer objCustomer = new Customer();
                    objCustomer.CustomerID = Convert.ToInt32(objDR[0]);
                    objCustomer.CustomerName = objDR[1] as string;
                    objCustomer.Gender = objDR[2] as string;
                    objCustomer.ContactNo = objDR[3] as string;
                    objCustomer.Email = objDR[4] as string;
                    objCustomer.Address = objDR[5] as string;
                    objCustomer.City = objDR[6] as string;
                    objCustomer.State = objDR[7] as string;
                    objCustomer.Pincode = Convert.ToInt32(objDR[8]);
                    objCustomers.Add(objCustomer);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCustomers;
        }

    }
}
