﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace OVSR.DataAccessLayer
{
    public class DealerDAL
    {
        //Add Dealer.................

        public bool AddDealerDAL(Dealer objDealer)
        {
            bool dealerAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_Adddealer", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //Sql command parameters......

                SqlParameter objSqlParam_DID = new SqlParameter("@DealerID", objDealer.DealerID);
                SqlParameter objSqlParam_DName = new SqlParameter("@DealerName", objDealer.DealerName);
                SqlParameter objSqlParam_CompanyName = new SqlParameter("@CompanyName", objDealer.CompanyName);
                SqlParameter objSqlParam_Address = new SqlParameter("@Address", objDealer.Address);
                SqlParameter objSqlParam_ContactNO = new SqlParameter("@ContactNo", objDealer.ContactNo);
                SqlParameter objSqlParam_City = new SqlParameter("@City", objDealer.City);
                SqlParameter objSqlParam_State= new SqlParameter("@State", objDealer.State);
                SqlParameter objSqlParam_Pincode = new SqlParameter("@Pincode", objDealer.Pincode);
                
                //Assiging of values.............

                objCom.Parameters.Add(objSqlParam_DID);
                objCom.Parameters.Add(objSqlParam_DName);
                objCom.Parameters.Add(objSqlParam_CompanyName);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_ContactNO);
                objCom.Parameters.Add(objSqlParam_City);
                objCom.Parameters.Add(objSqlParam_State);
                objCom.Parameters.Add(objSqlParam_Pincode);
                
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                dealerAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return dealerAdded;
        }

        //Get all Dealers Data...........

        public List<Dealer> GetAllDealersDAL()
        {
            List<Dealer> objDealers = new List<Dealer>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllDealer", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Dealer objDealer = new Dealer();

                    objDealer.DealerID = Convert.ToInt32(objDR[0]);
                    objDealer.DealerName = objDR[1] as string;
                    objDealer.CompanyName = objDR[2] as string;
                    objDealer.Address = objDR[3] as string;
                    objDealer.ContactNo =objDR[4] as string;
                    objDealer.City = objDR[5] as string;
                    objDealer.State = objDR[6] as string;
                    objDealer.Pincode = Convert.ToInt32(objDR[7]);
                    objDealers.Add(objDealer);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objDealers;
        }
    }
}
