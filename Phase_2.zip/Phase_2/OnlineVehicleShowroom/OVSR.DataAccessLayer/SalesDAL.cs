﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace OVSR.DataAccessLayer
{
    public class SalesDAL
    {
        //Add Sales Data...............

        public bool AddSalesDAL(Sales objSales)
        {
            bool salesAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_AddSales", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //Sql command parameters

                SqlParameter objSqlParam_salesID = new SqlParameter("@SalesID", objSales.SalesID);
                SqlParameter objSqlParam_vehicleID = new SqlParameter("@VehicleID", objSales.VehicleID);
                SqlParameter objSqlParam_customerID= new SqlParameter("@CustomerID", objSales.CustomerID);
                SqlParameter objSqlParam_showroomID= new SqlParameter("@ShowroomID", objSales.ShowroomID);
                SqlParameter objSqlParam_cost = new SqlParameter("@Cost", objSales.Cost);
                SqlParameter objSqlParam_orderDate = new SqlParameter("@OrderDate", objSales.OrderDate);
                SqlParameter objSqlParam_deliveryDate= new SqlParameter("@DeliveryDate", objSales.DeliveryDate);
                SqlParameter objSqlParam_remarks= new SqlParameter("@Remarks", objSales.Remarks);
              
                //Assiging of values...

                objCom.Parameters.Add(objSqlParam_salesID);
                objCom.Parameters.Add(objSqlParam_vehicleID);
                objCom.Parameters.Add(objSqlParam_customerID);
                objCom.Parameters.Add(objSqlParam_showroomID);
                objCom.Parameters.Add(objSqlParam_cost);
                objCom.Parameters.Add(objSqlParam_orderDate);
                objCom.Parameters.Add(objSqlParam_deliveryDate);
                objCom.Parameters.Add(objSqlParam_remarks);       
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                salesAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return salesAdded;
        }

        //get All Sales DAta..............

        public List<Sales> GetAllSalesDAL()
        {
            List<Sales> objSales = new List<Sales>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllSales", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Sales objsales = new Sales();

                    objsales.SalesID = Convert.ToInt32(objDR[0]);
                    objsales.VehicleID = Convert.ToInt32(objDR[1]);
                    objsales.CustomerID = Convert.ToInt32(objDR[2]);
                    objsales.ShowroomID = Convert.ToInt32(objDR[3]);
                    objsales.Cost = Convert.ToInt32(objDR[4]);
                    objsales.OrderDate = Convert.ToDateTime(objDR[5]);
                    objsales.DeliveryDate = Convert.ToDateTime(objDR[6]);
                    objsales.Remarks = objDR[7] as string;                   
                    objSales.Add(objsales);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objSales;
        }

        //Get All Customer Data for customer ID.....

        public List<Customer> GetAllCustomersDAL()
        {
            List<Customer> objCustomers=null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllCustomers", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();

                objCustomers = new List<Customer>();
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCustomers;
        }

        //Get all Vehicles Data for Vehicle ID.........

        public List<Vehicle> GetAllVehicleDAL()
        {
            List<Vehicle> objVehicles = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllVehicles", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();

                objVehicles = new List<Vehicle>();
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objVehicles;
        }

        //Get all Showroom Data For Showroom ID.................

        public List<Showroom> GetAllShowroomDAL()
        {
            List<Showroom> objShowrooms=null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllShowroom", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();

                objShowrooms = new List<Showroom>();
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objShowrooms;
        }

    }
}
