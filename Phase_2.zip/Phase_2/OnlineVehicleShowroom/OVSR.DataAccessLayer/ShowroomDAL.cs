﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace OVSR.DataAccessLayer
{
    public class ShowroomDAL
    {
        //Add Showroom Data......

        public bool AddShowroomDAL(Showroom objShowroom)
        {
            bool showroomAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_AddShowroom", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //Sql command parameters...........

                SqlParameter objSqlParam_sID = new SqlParameter("@ShowroomID", objShowroom.ShowroomID);
                SqlParameter objSqlParam_sName = new SqlParameter("@ShowroomName", objShowroom.ShowroomName);
                SqlParameter objSqlParam_dID = new SqlParameter("@DealerID", objShowroom.DealerID);
                SqlParameter objSqlParam_ownerName = new SqlParameter("@OwnerName", objShowroom.OwnerName);
                SqlParameter objSqlParam_cNO = new SqlParameter("@ContactNO", objShowroom.ContactNo);
                SqlParameter objSqlParam_address= new SqlParameter("@Address", objShowroom.Address);
                SqlParameter objSqlParam_city = new SqlParameter("@City", objShowroom.City);
                SqlParameter objSqlParam_state = new SqlParameter("@State", objShowroom.State);
                SqlParameter objSqlParam_pincode = new SqlParameter("@Pincode", objShowroom.Pincode);

                //assigning of values............

                objCom.Parameters.Add(objSqlParam_sID);
                objCom.Parameters.Add(objSqlParam_sName);
                objCom.Parameters.Add(objSqlParam_dID);
                objCom.Parameters.Add(objSqlParam_ownerName);
                objCom.Parameters.Add(objSqlParam_cNO);
                objCom.Parameters.Add(objSqlParam_address);
                objCom.Parameters.Add(objSqlParam_city);
                objCom.Parameters.Add(objSqlParam_state);
                objCom.Parameters.Add(objSqlParam_pincode);

                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                showroomAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return showroomAdded;
        }

        //Get all Showroom Data............

        public List<Showroom> GetAllShowroomDAL()
        {
            List<Showroom> objShowrooms = new List<Showroom>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllShowroom", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Showroom objShowroom = new Showroom();

                    objShowroom.ShowroomID = Convert.ToInt32(objDR[0]);
                    objShowroom.ShowroomName = objDR[1] as string;
                    objShowroom.DealerID =Convert.ToInt32( objDR[2]);
                    objShowroom.OwnerName = objDR[3] as string;
                    objShowroom.ContactNo = objDR[4] as string;
                    objShowroom.Address = objDR[5] as string;
                    objShowroom.City = objDR[6] as string;
                    objShowroom.State = objDR[7] as string;
                    objShowroom.Pincode = Convert.ToInt32(objDR[8]);
                    objShowrooms.Add(objShowroom);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objShowrooms;
        }

        //Get all Dealers for Delaer ID............

        public List<Dealer> GetAllDealerDAL()
        {
            List<Dealer> objDealers = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllDealer", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();

                objDealers = new List<Dealer>();
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objDealers;
        }
    }
}
