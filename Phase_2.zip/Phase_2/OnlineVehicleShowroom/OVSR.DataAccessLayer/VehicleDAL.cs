﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVSR.Entities;
using OVSR.Exceptions;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace OVSR.DataAccessLayer
{
    public class VehicleDAL
    {
        //Add Vehicle Data.......

        public bool AddVehicleDAL(Vehicle objVehicle)
        {
            bool vehicleAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_AddVehicle", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_VID= new SqlParameter("@VehicleID", objVehicle.VehicleID);
                SqlParameter objSqlParam_VName = new SqlParameter("@VehicleName", objVehicle.VehicleName);
                SqlParameter objSqlParam_VModel = new SqlParameter("@VehicleModel", objVehicle.VehicleModel);
                SqlParameter objSqlParam_DealerID = new SqlParameter("@DealerID", objVehicle.DealerID);
                SqlParameter objSqlParam_Cost = new SqlParameter("@Cost", objVehicle.Cost);
                SqlParameter objSqlParam_Totalstock= new SqlParameter("@TotalStock", objVehicle.TotalStock);
                SqlParameter objSqlParam_Description= new SqlParameter("@Description", objVehicle.Description);
                SqlParameter objSqlParam_Rating = new SqlParameter("@Rating", objVehicle.Rating);

                //
                objCom.Parameters.Add(objSqlParam_VID);
                objCom.Parameters.Add(objSqlParam_VName);
                objCom.Parameters.Add(objSqlParam_VModel);
                objCom.Parameters.Add(objSqlParam_DealerID);
                objCom.Parameters.Add(objSqlParam_Cost);
                objCom.Parameters.Add(objSqlParam_Totalstock);
                objCom.Parameters.Add(objSqlParam_Description);
                objCom.Parameters.Add(objSqlParam_Rating);

                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                vehicleAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return vehicleAdded;
        }

        //Get all Vehicle Data........

        public List<Vehicle> GetAllVehicleDAL()
        {
            List<Vehicle> objVehicles = new List<Vehicle>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllVehicles", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Vehicle objVehicle = new Vehicle();

                    objVehicle.VehicleID = Convert.ToInt32(objDR[0]);
                    objVehicle.VehicleName = objDR[1] as string;

                    objVehicle.VehicleModel = objDR[2] as string;
                    objVehicle.DealerID = Convert.ToInt32( objDR[3]) ;
                    objVehicle.Cost =Convert.ToDouble(objDR[4]);
                    objVehicle.TotalStock = Convert.ToInt32( objDR[5]) ;
                    objVehicle.Description = objDR[6] as string;
                    objVehicle.Rating = Convert.ToInt32(objDR[7]);

                    objVehicles.Add(objVehicle);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objVehicles;
        }

        //Update Vehicle Data.......

        public bool UpdateVehicleDAL(Vehicle objVehicle)
        {
            bool vehicleUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_UpdateVehicle", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_VID = new SqlParameter("@VehicleID", objVehicle.VehicleID);
                SqlParameter objSqlParam_VName = new SqlParameter("@VehicleName", objVehicle.VehicleName);
                SqlParameter objSqlParam_VModel = new SqlParameter("@VehicleModel", objVehicle.VehicleModel);
                SqlParameter objSqlParam_DealerID= new SqlParameter("@DealerID", objVehicle.DealerID);
                SqlParameter objSqlParam_Cost = new SqlParameter("@Cost", objVehicle.Cost);
                SqlParameter objSqlParam_TotalStock= new SqlParameter("@TotalStock", objVehicle.TotalStock);
                SqlParameter objSqlParam_Description = new SqlParameter("@Description", objVehicle.Description);
                SqlParameter objSqlParam_Rating = new SqlParameter("@Rating", objVehicle.Rating);
               
                //
                objCom.Parameters.Add(objSqlParam_VID);
                objCom.Parameters.Add(objSqlParam_VName);
                objCom.Parameters.Add(objSqlParam_VModel);
                objCom.Parameters.Add(objSqlParam_DealerID);
                objCom.Parameters.Add(objSqlParam_Cost);
                objCom.Parameters.Add(objSqlParam_TotalStock);
                objCom.Parameters.Add(objSqlParam_Description);
                objCom.Parameters.Add(objSqlParam_Rating);
                
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                vehicleUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return vehicleUpdated;
        }

        //Search Vehicle By ID........

        public Vehicle SearchVehicleDAL(int VehicleId)
        {
            Vehicle objVehicle = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_SearchVehicleById", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_VId = new SqlParameter("@VehicleID", SqlDbType.Int);
                SqlParameter objSqlParam_VName = new SqlParameter("@VehicleName", SqlDbType.VarChar, 30);
                SqlParameter objSqlParam_VModel = new SqlParameter("@VehicleModel", SqlDbType.VarChar, 30);
                SqlParameter objSqlParam_DealerID = new SqlParameter("@DealerID", SqlDbType.Int);
                SqlParameter objSqlParam_Cost = new SqlParameter("@Cost", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_TotalStock = new SqlParameter("@TotalStock", SqlDbType.Int);
                SqlParameter objSqlParam_Description = new SqlParameter("@Description", SqlDbType.VarChar, 30);
                SqlParameter objSqlParam_Rating = new SqlParameter("@Rating", SqlDbType.Int);
                SqlParameter objSqlParam_VehicleExists = new SqlParameter("@VehicleExists", SqlDbType.Int);

                //
                objSqlParam_VId.Direction = ParameterDirection.Input;
                objSqlParam_VName.Direction = ParameterDirection.Output;
                objSqlParam_VModel.Direction = ParameterDirection.Output;
                objSqlParam_DealerID.Direction = ParameterDirection.Output;
                objSqlParam_Cost.Direction = ParameterDirection.Output;
                objSqlParam_TotalStock.Direction = ParameterDirection.Output;
                objSqlParam_Description.Direction = ParameterDirection.Output;
                objSqlParam_Rating.Direction = ParameterDirection.Output;
                objSqlParam_VehicleExists.Direction = ParameterDirection.Output;

                //
                objCom.Parameters.Add(objSqlParam_VId);
                objCom.Parameters.Add(objSqlParam_VName);
                objCom.Parameters.Add(objSqlParam_VModel);
                objCom.Parameters.Add(objSqlParam_DealerID);
                objCom.Parameters.Add(objSqlParam_Cost);
                objCom.Parameters.Add(objSqlParam_TotalStock);
                objCom.Parameters.Add(objSqlParam_Description);
                objCom.Parameters.Add(objSqlParam_Rating);
                objCom.Parameters.Add(objSqlParam_VehicleExists);

                //
                objSqlParam_VId.Value = VehicleId;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objVehicle = new Vehicle();
                objVehicle.VehicleID = VehicleId;
                if (Convert.ToInt32(objSqlParam_VehicleExists.Value) == 1)
                {
                    objVehicle.VehicleName = objSqlParam_VName.Value as string;
                    objVehicle.VehicleModel = objSqlParam_VModel.Value as string;
                    objVehicle.DealerID = Convert.ToInt32(objSqlParam_DealerID.Value);
                    objVehicle.Cost = Convert.ToDouble(objSqlParam_Cost.Value);
                    objVehicle.TotalStock = Convert.ToInt32(objSqlParam_TotalStock.Value);
                    objVehicle.Description = objSqlParam_Description.Value as string;
                    objVehicle.Rating = Convert.ToInt32(objSqlParam_Rating.Value);

                }
                else if (Convert.ToInt32(objSqlParam_VehicleExists.Value) == 2)
                {
                    return null;
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objVehicle;
        }

        //Get all Dealers for Dealer ID...............

        public DataTable GetAllDealerDAL()
        {

            DataTable dealerList = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["OVSRConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[ar177501].USP_ListAllDealer", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();

                dealerList = new DataTable();
                dealerList.Load(objDR);
            }
            catch (SqlException objSqlEx)
            {
                throw new OVSRException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return dealerList;
        }

    }
}
