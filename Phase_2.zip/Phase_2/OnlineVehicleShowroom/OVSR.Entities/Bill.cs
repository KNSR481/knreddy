﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OVSR.Entities
{
    public class Bill
    {
        public int BillID { get; set; }
        public int SalesID { get; set; }
        public int VehicleID { get; set; }
        public int Quantity { get; set; }
        public string CustomerName{ get; set; }
        public int ShowroomID { get; set; }
        public int Cost { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }

        public Bill()
        {

        }

    }
}
