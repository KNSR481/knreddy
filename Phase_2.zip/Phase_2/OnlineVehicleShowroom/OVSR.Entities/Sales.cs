﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OVSR.Entities
{
    public class Sales
    {
        public int SalesID { get; set; }
        public int VehicleID { get; set; }
        public int CustomerID { get; set; }
        public int ShowroomID { get; set; }
        public int Cost { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string Remarks { get; set; }

        public Sales()
        {

        }

        public bool AddSalesDAL(Sales sales)
        {
            throw new NotImplementedException();
        }
    }
}
