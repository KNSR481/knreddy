﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OVSR.Exceptions
{
    public class OVSRException : ApplicationException
    {
        public OVSRException() : base()
        {

        }

        public OVSRException(string message) : base(message)
        {

        }

        public OVSRException(string message, Exception innerException)
            : base(innerException: innerException, message: message)
        {

        }
    }
}
