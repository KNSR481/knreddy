﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVSR.Entities;
using OVSR.Exceptions;
using OVSR.DataAccessLayer;
using OVSR.BusinessLayer;

namespace OnlineVehicleShowroom
{
    /// <summary>
    /// Interaction logic for BillPL.xaml
    /// </summary>
    public partial class BillPL : Window
    {
        public BillPL()
        {
            InitializeComponent();
        }

        //Validation part......

        private bool ValidateUI()
        {
            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if (cmbSID.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Sales Id should not be Empty" + Environment.NewLine);
            }

            if (txtQuantity.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Quantity  should not be Empty" + Environment.NewLine);
            }
            if (!isValid)
            {
                throw new OVSRException(sb.ToString());
            }
            return isValid;
        }

        //Generate bill Butoon......

        private void BtngenerateBill_Click(object sender, RoutedEventArgs e)
        {
            Generatebill();
        }

        //Button for All bill records...........

        private void Btnrecord_Click(object sender, RoutedEventArgs e)
        {
            GetBills();
            dgBill.Visibility = Visibility.Visible;

        }

        //Button for Back........

        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win1 = new MainWindow();
            win1.Show();
            this.Close();

        }

        //Button for adiing of bill details.......

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (ValidateUI())
                {
                    AddBill();
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }


            Clear();

        }

        //Clear Method........

        private void Clear()
        {
            txtvehicleid.Clear();
            txtcustomerName.Clear();
            cmbSID.SelectedIndex = -1; ;
            txtshowrromid.Clear();
            txtTotalamount.Clear();
            txtOrderdate.Text = string.Empty;
            txtDeliverydate.Text = string.Empty;

            dgBill.DataContext = null;
        }

        //generate bill

        private void Generatebill()
        {
            try
            {
                int id;
                Bill objBill;
                int qty, result, cost;
                id = Convert.ToInt32(cmbSID.SelectedValue);
                objBill = BillBL.GenerateBillBL(id);
                qty = Convert.ToInt32(txtQuantity.Text);
                cost = Convert.ToInt32(objBill.Cost);
                
                result = qty * cost;
              
                if (objBill != null)
                {
                    txtvehicleid.Text = Convert.ToString(objBill.VehicleID);
                    txtcustomerName.Text = objBill.CustomerName;
                    txtshowrromid.Text = Convert.ToString(objBill.ShowroomID);
                    txtTotalamount.Text = Convert.ToString(result);
                    txtOrderdate.Text = objBill.OrderDate.ToString();
                    txtDeliverydate.Text = objBill.DeliveryDate.ToString();



                    dgBill.Visibility = Visibility.Collapsed;

                    
                    lbdisSalesId.Content = cmbSID.SelectedValue;
                    lbdiscustomerId.Content = txtcustomerName.Text;
                    lbdisshowroomId.Content = txtshowrromid.Text;
                    lbdisOrderdate.Content = txtOrderdate.Text;
                    lbdisDeliverydate.Content = txtDeliverydate.Text;
                    lbdisTotalamountId.Content = txtTotalamount.Text;
                    lbdisvehicleId.Content = txtvehicleid.Text;
                    lbdisquanity.Content = txtQuantity.Text;

                }
                else
                {
                    MessageBox.Show("Bill Can't Be Generated");
                }

                if(objBill!=null)
                {

                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //List All Bilss.........

        private void GetBills()
        {
            try
            {
                List<Bill> objBills = BillBL.GetAllBillsBL();
                if (objBills != null)
                {
                    dgBill.ItemsSource = objBills;
                }
                else
                {
                    MessageBox.Show("No Records available");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Add Bill Data....

        private void AddBill()
        {
            try
            {
                int salesId;
                int quantity;
                int vehicleId;
                string customerName;
                int showroomId;
                int cost;
                DateTime orderdate;
                DateTime deliverydate;
                //
                bool billAdded;
                //
                salesId = Convert.ToInt32(cmbSID.SelectedValue);
                quantity = Convert.ToInt32(txtQuantity.Text);
                vehicleId = Convert.ToInt32(txtvehicleid.Text);
                customerName = txtcustomerName.Text;
                showroomId = Convert.ToInt32(txtshowrromid.Text);
                cost = Convert.ToInt32(txtTotalamount.Text);
                orderdate = (DateTime)txtOrderdate.SelectedDate;
                deliverydate = (DateTime)txtDeliverydate.SelectedDate;
                //
                Bill objBill = new Bill
                {
                    SalesID = salesId,
                    Quantity = quantity,
                    VehicleID = vehicleId,
                    CustomerName = customerName,
                    ShowroomID = showroomId,
                    Cost = cost,
                    OrderDate = orderdate,
                    DeliveryDate = deliverydate,
                };

                billAdded = BillBL.AddBillBL(objBill);
                if (billAdded == true)
                {
                    MessageBox.Show("Bill Record Added!!!");


                }
                else
                {
                    MessageBox.Show("Bill Record couldn't be Added!!!");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //Get all Sales datafor sales ID...
       
        private void GetSales()
        {
            try
            {
                List<Sales> objsales = SalesBL.GetAllSalesBL();
                if (objsales != null)
                {
                    cmbSID.ItemsSource = objsales;
                    cmbSID.DisplayMemberPath = "SalesID";
                    cmbSID.SelectedValuePath = " SalesID";

                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetSales();
        }
    }
}
