﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVSR.Entities;
using OVSR.Exceptions;
using OVSR.DataAccessLayer;
using OVSR.BusinessLayer;
using System.Text.RegularExpressions;

namespace OnlineVehicleShowroom
{
    /// <summary>
    /// Interaction logic for CustomerPL.xaml
    /// </summary>
    public partial class CustomerPL : Window
    {
        public CustomerPL()
        {
            InitializeComponent();
        }

        //Validation part.....

        private bool ValidateUI()
        {
            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if(txtCustID.Text==string.Empty)
            {
                isValid = false;
                sb.Append("i.Customer Id should not be Empty" + Environment.NewLine);
            }

            if (txtCustName.Text == string.Empty)
            {
                isValid = false;
                sb.Append("ii.Customer Name should not be Empty" + Environment.NewLine);
            }

            if (txtEmail.Text == string.Empty)
            {
                isValid = false;
                sb.Append("iii.Email Id should not be Empty" + Environment.NewLine);
            }
            if (!Regex.IsMatch(txtEmail.Text, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
            {
                isValid = false;
                sb.Append("iv.Email is not valid format!" + Environment.NewLine);
            }
            if (txtPinCode.Text == string.Empty)
            {
                isValid = false;
                sb.Append("v.pincode should not be Empty" + Environment.NewLine);
            }
            if (txtAddress.Text == string.Empty)
            {
                isValid = false;
                sb.Append("vi.Address should not be Empty" + Environment.NewLine);
            }
            if (txtCity.Text == string.Empty)
            {
                isValid = false;
                sb.Append("vii.city should not be Empty" + Environment.NewLine);
            }
            if (txtState.Text == string.Empty)
            {
                isValid = false;
                sb.Append("viii.state should not be Empty" + Environment.NewLine);
            }
            if (txtCNO.Text == string.Empty)
            {
                isValid = false;
                sb.Append("ix.Contact number should not be Empty" + Environment.NewLine);
            }
            if (!Regex.Match(txtPinCode.Text, "[0-9]{6}").Success)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "x.Required 6 digit Pincode");
            }
            if (!Regex.Match(txtCNO.Text,"[0-9]{10}").Success)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "xi.Required 10 digit Contact Number");
            }
            if (txtPinCode.Text == string.Empty)
            {
                isValid = false;
                sb.Append("xii.Pincode should not be Empty" + Environment.NewLine);
            }
            if(!isValid)
            {
                throw new OVSRException(sb.ToString());
            }
            return isValid;
        }

        //Button for Add.

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateUI())
                {
                    AddCustomer();                  
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
           
           // Clear();
            
        }

        //Button for List.....

        private void BtnList_Click(object sender, RoutedEventArgs e)
        {
            GetCustomers();
            Clear();
        }

        //button for Update...

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            UpdateCustomer();
            Clear();
        }

        //Button for Search.........

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchCustomer();
        }

        //Clear Method...........

        private void Clear()
        {
            txtCustID.Clear();
            txtCustName.Clear();
            txtCNO.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            txtCity.Clear();
            txtState.Clear();
            txtPinCode.Clear();
            rbmale.IsChecked = false;
            rbfemale.IsChecked = false;
            dgCustomers.DataContext = null;
        }

        //Add Customer
        private void AddCustomer()
        {
            
                try
                {
                    int id;
                    string name;
                    string gender;
                    string contactNo;
                    string email;
                    string address;
                    string city;
                    string state;
                    int pincode;

                    //
                    bool customerAdded;

                    //
                    if (rbmale.IsChecked == true)
                    {
                        gender = " Male";
                    }
                    else
                    {
                        gender = "Female";
                    }

                    id = Convert.ToInt32(txtCustID.Text);
                    name = txtCustName.Text;
                    contactNo = txtCNO.Text;
                    email = txtEmail.Text;
                    address = txtAddress.Text;
                    city = txtCity.Text;
                    state = txtState.Text;
                    pincode = Convert.ToInt32(txtPinCode.Text);

                    //
                    Customer objcustomer = new Customer
                    {
                        CustomerID = id,
                        CustomerName = name,
                        Gender = gender,
                        ContactNo = contactNo,
                        Email = email,
                        Address = address,
                        City = city,
                        State = state,
                        Pincode = pincode
                    };

                    customerAdded = CustomerBL.AddCustomerBL(objcustomer);
                    if (customerAdded == true)
                    {
                        MessageBox.Show("Customer record added successfully.");

                    }
                    else
                    {
                        MessageBox.Show("Customer record couldn't be added.");
                    }
                }
                
                
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Update Customer
        private void UpdateCustomer()
        {
            try
            {
                int id;
                string name;
                string gender;
                string contactNo;
                string email;
                string address;
                string city;
                string state;
                int pincode;

                //
                bool customerAdded;
                //

                if (rbmale.IsChecked == true)
                {
                    gender = " Male";
                }
                else
                {
                    gender = "Female";
                }
                id = Convert.ToInt32(txtCustID.Text);
                name = txtCustName.Text;
                contactNo = txtCNO.Text;
                email = txtEmail.Text;
                address = txtAddress.Text;
                city = txtCity.Text;
                state = txtState.Text;
                pincode = Convert.ToInt32(txtPinCode.Text);

                //

                Customer objcustomer = new Customer
                {
                    CustomerID = id,
                    CustomerName = name,
                    Gender = gender,
                    ContactNo = contactNo,
                    Email = email,
                    Address = address,
                    City = city,
                    State = state,
                    Pincode = pincode
                };
                customerAdded = CustomerBL.UpdateCustomerBL(objcustomer);
                if (customerAdded == true)
                {
                    MessageBox.Show("Customer record Updated successfully.");
                }
                else
                {
                    MessageBox.Show("Customer record couldn't be Updated.");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Search Customer
        private void SearchCustomer()
        {
            try
            {
                int id;
                //
                Customer objCustomer;
                //
                id = Convert.ToInt32(txtCustID.Text);
                //
                objCustomer = CustomerBL.SearchCustomerBL(id);
                if (objCustomer != null)
                {
                    txtCustName.Text = objCustomer.CustomerName;
                    txtCNO.Text = Convert.ToString(objCustomer.ContactNo);
                    //bool isChecked = radioButton.Checked;
                    if (objCustomer.Gender == "Male")
                    {
                        rbmale.IsChecked = true;
                    }
                    else
                    {
                        rbfemale.IsChecked = true;
                    }



                    txtEmail.Text = objCustomer.Email;

                    txtAddress.Text = objCustomer.Address;

                    txtCity.Text = objCustomer.City;

                    txtState.Text = objCustomer.State;

                    txtPinCode.Text = Convert.ToString(objCustomer.Pincode);


                }
                else
                {
                    MessageBox.Show("Employee record couldn't be found.");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Get All Customers
        private void GetCustomers()
        {
            try
            {
                List<Customer> objCustomers = CustomerBL.GetAllCustomersBL();
                if (objCustomers != null)
                {
                    dgCustomers.ItemsSource = objCustomers;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //Window for navigation for Main Window

        private void Btnclear_Click(object sender, RoutedEventArgs e)
        {

            MainWindow win1 = new MainWindow();
            win1.Show();
            this.Close();

        }
    }
}
