﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVSR.Entities;
using OVSR.Exceptions;
using OVSR.DataAccessLayer;
using OVSR.BusinessLayer;
using System.Text.RegularExpressions;

namespace OnlineVehicleShowroom
{
    /// <summary>
    /// Interaction logic for DealerPL.xaml
    /// </summary>
    public partial class DealerPL : Window
    {
        public DealerPL()
        {
            InitializeComponent();
        }

        //Validation Part.........

        private bool ValidateUI()
        {
            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if (txtDealerID.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Dealer Id should not be Empty" + Environment.NewLine);
            }

            if (txtDealerName.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Dealer Name should not be Empty" + Environment.NewLine);
            }
            if (!Regex.Match(txtPincode.Text, "[0-9]{6}").Success)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Required 6 digit Pincode");
            }
            if (!Regex.Match(txtCNO.Text, "[0-9]{10}").Success)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Required 10 digit Contact Number");
            }
            if (txtCompanyName.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Company Name should not be Empty" + Environment.NewLine);
            }
            
            if (txtAddress.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Address should not be Empty" + Environment.NewLine);
            }
            if (txtCity.Text == string.Empty)
            {
                isValid = false;
                sb.Append("city should not be Empty" + Environment.NewLine);
            }
            if (txtState.Text == string.Empty)
            {
                isValid = false;
                sb.Append("state should not be Empty" + Environment.NewLine);
            }
            if (txtCNO.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Contact number should not be Empty" + Environment.NewLine);
            }
            if (txtPincode.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Pincode should not be Empty" + Environment.NewLine);
            }
            if (!isValid)
            {
                throw new OVSRException(sb.ToString());
            }
            return isValid;
        }

        //Button for add........

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateUI())
                {
                    AddDealer();
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }


            Clear();
        }

        //Button for List........

        private void BtnList_Click(object sender, RoutedEventArgs e)
        {
            GetDealers();
        }

        //Button For nagivate to mainWindow

        private void Btnclear_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win1 = new MainWindow();
            win1.Show();
            this.Close();

        }

        //Clear method

        private void Clear()
        {
            txtDealerID.Clear();
            txtDealerName.Clear();
            txtCompanyName.Clear();
            txtAddress.Clear();
            txtCNO.Clear();
            txtCity.Clear();
            txtState.Clear();
            txtPincode.Clear();
            
            dgDealers.DataContext = null;
        }

        //Add Dealer......

        private void AddDealer()
        {
            try
            {
                int dID;
                string dealerName;
                string companyName;
                string address;
                string contactNO;
                string city;
                string state;
                int pincode;

                bool dealerAdded;

                //
                dID = Convert.ToInt32(txtDealerID.Text);
                dealerName = txtDealerName.Text;
                companyName = txtCompanyName.Text;
                address = txtAddress.Text;
                contactNO =  txtCNO.Text;
                city = txtCity.Text;
                state = txtState.Text;
                pincode = Convert.ToInt32(txtPincode.Text);

                //
                Dealer objdealer = new Dealer
                {
                    DealerID = dID,
                    DealerName = dealerName,
                    CompanyName = companyName,
                    Address = address,
                    ContactNo = contactNO,
                    City = address,
                    State = state,                 
                    Pincode = pincode
                };
                dealerAdded = DealerBL.AddDealerBL(objdealer);
                if (dealerAdded == true)
                {
                    MessageBox.Show("Dealer record added successfully.");

                }
                else
                {
                    MessageBox.Show("Dealer record couldn't be added.");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Get All Dealers.......

        private void GetDealers()
        {
            try
            {
                List<Dealer> objDealers = DealerBL.GetAllDealersBL();
                if (objDealers != null)
                {
                    dgDealers.ItemsSource = objDealers;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

      
    }
}
