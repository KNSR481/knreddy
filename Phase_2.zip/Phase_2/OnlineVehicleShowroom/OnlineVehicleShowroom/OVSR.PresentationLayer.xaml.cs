﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OnlineVehicleShowroom
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //button for navigate to customer window.

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CustomerPL win1 = new CustomerPL();
            win1.Show();
            this.Close();
        }

        //button for navigate to Dealer Window

        private void LblDealerWindow_Click(object sender, RoutedEventArgs e)
        {
            DealerPL win2 = new DealerPL();
            win2.Show();
            this.Close();
        }

        //button for navigate to Vehicle Window

        private void LblVehicleWindow_Click(object sender, RoutedEventArgs e)
        {
           VehiclePL win3 = new VehiclePL();
           win3.Show();
            this.Close();
        }

        //button for navigate to Showroom Window

        private void LblShowroomWindow_Click(object sender, RoutedEventArgs e)
        {
            ShowroomPL win4 = new ShowroomPL();
            win4.Show();
            this.Close();
        }

        //button for navigate to Sales Window

        private void LblSalesWindow_Click(object sender, RoutedEventArgs e)
        {
            SalesPL win5 = new SalesPL();
            win5.Show();
            this.Close();
        }

        //button for navigate to Bill Window

        private void LblBillWindow_Click(object sender, RoutedEventArgs e)
        {
            BillPL win6 = new BillPL();
            win6.Show();
            this.Close();
        }

        //button for navigate to Purchase Window

        private void Btnpurchasedata_Click(object sender, RoutedEventArgs e)
        {
            PurchasePL win7 = new PurchasePL();
            win7.Show();
            this.Close();
        }
    }
}
