﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVSR.Entities;
using OVSR.Exceptions;
using OVSR.DataAccessLayer;
using OVSR.BusinessLayer;


namespace OnlineVehicleShowroom
{
    /// <summary>
    /// Interaction logic for PurchasePL.xaml
    /// </summary>
    public partial class PurchasePL : Window
    {
        public PurchasePL()
        {
            InitializeComponent();
        }

        //Button for Search

        private void BtnShow_Click(object sender, RoutedEventArgs e)
        {
            SearchPurchasedata();
        }

        //Purchase data Method......

        private void SearchPurchasedata()
        {
            try
            {
                int billid;
                //
                Bill objBill;
                //
                billid = Convert.ToInt32(txtbillid.Text);
                //
                objBill = BillBL.SearchPurchaseBL(billid);
                if (objBill != null)
                {
                    txtsalesid.Text = Convert.ToString(objBill.SalesID);

                    txtvehicleid.Text = Convert.ToString(objBill.VehicleID);
                 
                    txtcustname.Text = objBill.CustomerName;

                    txtsrid.Text = Convert.ToString(objBill.ShowroomID);

                    txtTPA.Text = Convert.ToString(objBill.Cost);

                    txtorderdate.Text = Convert.ToString(objBill.OrderDate);

                    txtdeliverydate.Text = Convert.ToString(objBill.DeliveryDate);

                    txtQuantity.Text = Convert.ToString(objBill.Quantity);

                }
                else
                {
                    MessageBox.Show("purchase  data couldn't be found.");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Button for navigate to main window.....

        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win1 = new MainWindow();
            win1.Show();
            this.Close();
        }
    }
}
