﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVSR.Entities;
using OVSR.Exceptions;
using OVSR.DataAccessLayer;
using OVSR.BusinessLayer;

namespace OnlineVehicleShowroom
{
    /// <summary>
    /// Interaction logic for SalesPL.xaml
    /// </summary>
    public partial class SalesPL : Window
    {
        public SalesPL()
        {
            InitializeComponent();
        }

        //Validation part.....

        private bool ValidateUI()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (txtSalesID.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Sales Id should not be Empty" + Environment.NewLine);
            }

            if (cmbVID.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Vehicle ID should not be Empty" + Environment.NewLine);
            }

            if (cmbCstID.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Customer ID should not be Empty" + Environment.NewLine);
            }

            if (cmbSRId.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Showroom ID should not be Empty" + Environment.NewLine);
            }
            if (txtCost.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Cost should not be Empty" + Environment.NewLine);
            }
            if (txtOrderdate.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Order Date Should not be Empty" + Environment.NewLine);
            }
            if (txtDeliverydate.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Delivery Date should not be Empty" + Environment.NewLine);
            }
            if (txtRemarks.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Remarks should not be Empty" + Environment.NewLine);
            }
            if (!isValid)
            {
                throw new OVSRException(sb.ToString());
            }

            return isValid;
        }

        //button for add.

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateUI())
                {
                    AddSales();
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }


            Clear();

        }

        //button for List.........

        private void BtnList_Click(object sender, RoutedEventArgs e)
        {
            GetSales();
        }

        //Button for back to main window.

        private void Btnback_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win1 = new MainWindow();
            win1.Show();
            this.Close();
        }

        //Clear Method.....

        private void Clear()
        {
            txtSalesID.Clear();
            cmbVID.SelectedIndex=-1;
            cmbCstID.SelectedIndex = -1;
            cmbSRId.SelectedIndex = -1;
            txtCost.Clear();
            txtOrderdate.Text=string.Empty;
            txtDeliverydate.Text = string.Empty;
            txtRemarks.Clear();
          

            dgSales.DataContext = null;
        }

        //Add Sales.............

        private void AddSales()
        {
            try
            {
                int sID;
                int vID;
                int cID;
                int srID;
                int cost;
                DateTime orderDate;
                DateTime deliveryDate;
                string remarks;
               
                bool salesAdded;

                //
                sID = Convert.ToInt32(txtSalesID.Text);
                vID = Convert.ToInt32(cmbVID.SelectedValue);
                cID = Convert.ToInt32(cmbCstID.SelectedValue);
                srID = Convert.ToInt32(cmbSRId.SelectedValue);
                cost = Convert.ToInt32(txtCost.Text);
                orderDate = Convert.ToDateTime(txtOrderdate.Text);
                deliveryDate = Convert.ToDateTime(txtDeliverydate.Text);
                remarks = txtRemarks.Text;
               
                //
                Sales objsales = new Sales
                {
                    SalesID = sID,
                    VehicleID = vID,
                    CustomerID = cID,
                    ShowroomID = srID,
                    Cost = cost,
                    OrderDate = orderDate,
                    DeliveryDate = deliveryDate,
                    Remarks = remarks,
                  
                };
                salesAdded = SalesBL.AddSalesBL(objsales);
                if (salesAdded == true)
                {
                    MessageBox.Show("Sales record added successfully.");

                }
                else
                {
                    MessageBox.Show("Sales record couldn't be added.");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Get All Sales............

        private void GetSales()
        {
            try
            {
                List<Sales> objSales = SalesBL.GetAllSalesBL();
                if (objSales != null)
                {
                    dgSales.ItemsSource = objSales;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //Get all Sales for Customer ID............

        private void GetCustomers()
        {
            try
            {
                List<Customer> objcustomer = CustomerBL.GetAllCustomersBL();
                if (objcustomer != null)
                {
                    cmbCstID.ItemsSource = objcustomer;
                    cmbCstID.DisplayMemberPath = "CustomerName";
                    cmbCstID.SelectedValuePath = " CustomerID";

                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //Get all Showroom for Showroom ID.......

        private void GetShowroom()
        {
            try
            {
                List<Showroom> objshowroom = ShowroomBL.GetAllShowroomsBL();
                if (objshowroom != null)
                {
                    cmbSRId.ItemsSource = objshowroom;
                    cmbSRId.DisplayMemberPath = "ShowroomName";
                    cmbSRId.SelectedValuePath = " ShowroomID";

                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //Get all vehicles for Vehicle ID..............

        private void GetVehicles()
        {
            try
            {
                List<Vehicle> objvehicle = VehicleBL.GetAllVehiclesBL();
                if (objvehicle != null)
                {
                    cmbVID.ItemsSource = objvehicle;
                    cmbVID.DisplayMemberPath = "VehicleName";
                    cmbVID.SelectedValuePath = " VehicleID";

                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //wINDOW LOAD FRO GET aLL FOREIGN KEYS......

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetCustomers();
            GetVehicles();
            GetShowroom();
        }
    }
}
