﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVSR.Entities;
using OVSR.Exceptions;
using OVSR.DataAccessLayer;
using OVSR.BusinessLayer;
using System.Text.RegularExpressions;


namespace OnlineVehicleShowroom
{
    /// <summary>
    /// Interaction logic for ShowroomPL.xaml
    /// </summary>
    public partial class ShowroomPL : Window
    {
        public ShowroomPL()
        {
            InitializeComponent();
        }

        //Validation Part................

        private bool ValidateUI()
        {
            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if (txtShowroomID.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Showroom Id should not be Empty" + Environment.NewLine);
            }

            if (txtShowroomName.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Showroom Name should not be Empty" + Environment.NewLine);
            }

            if (cmbDealerID.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Dealer ID should not be Empty" + Environment.NewLine);
            }

            if (txtOwnerName.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Owner Name should not be Empty" + Environment.NewLine);
            }
            if (txtAddress.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Address should not be Empty" + Environment.NewLine);
            }
            if (txtCity.Text == string.Empty)
            {
                isValid = false;
                sb.Append("city should not be Empty" + Environment.NewLine);
            }
            if (txtState.Text == string.Empty)
            {
                isValid = false;
                sb.Append("state should not be Empty" + Environment.NewLine);
            }
            if (txtCNO.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Contact number should not be Empty" + Environment.NewLine);
            }
            if (txtPincode.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Pincode should not be Empty" + Environment.NewLine);
            }
            if (!Regex.Match(txtCNO.Text, "[0-9]{10}").Success)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Required 10 digit Contact Number");
            }
            if (!Regex.Match(txtPincode.Text, "[0-9]{6}").Success)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Required 6 digit Pincode");
            }

            if (!isValid)
            {
                throw new OVSRException(sb.ToString());
            }
            return isValid;
        }

        //Window load for get Dealer ID............

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDealers();
        }

        //Button for Add..........

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateUI())
                {
                    AddShowroom();
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }


            Clear();
        }

        //Button for List..............

        private void BtnList_Click(object sender, RoutedEventArgs e)
        {
            GetShowroom();
            Clear();

        }

        //Button to get Main Window..........

        private void Btnclear_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win1 = new MainWindow();
            win1.Show();
            this.Close();
        }

        //Clear Method.................

        private void Clear()
        {
            txtShowroomID.Clear();
            txtShowroomName.Clear();
            cmbDealerID.SelectedIndex=-1;
            txtOwnerName.Clear();
            txtCNO.Clear();
            txtAddress.Clear();
            txtCity.Clear();
            txtState.Clear();
            txtPincode.Clear();

            dgShowroom.DataContext = null;
        }

        //Add Showroom

        private void AddShowroom()
        {
            try
            {
                int sID;
                string showroomName;
                int dealerID;
                string ownerName;
                string contactNO;
                string address;
                string city;
                string state;
                int pincode;

                bool showroomAdded;

                //
                sID = Convert.ToInt32(txtShowroomID.Text);
                showroomName = txtShowroomName.Text;
                dealerID =Convert.ToInt32(cmbDealerID.SelectedValue);
                ownerName = txtOwnerName.Text;
                contactNO = txtCNO.Text;
                address = txtAddress.Text;
                city = txtCity.Text;
                state = txtState.Text;
                pincode = Convert.ToInt32(txtPincode.Text);

                //
                Showroom objshowroom = new Showroom
                {
                    ShowroomID = sID,
                    ShowroomName = showroomName,
                    DealerID = dealerID,
                    OwnerName=ownerName,
                    ContactNo =contactNO,
                    Address = address,
                    City = city,
                    State = state,
                    Pincode = pincode
                };
                showroomAdded = ShowroomBL.AddShowroomBL(objshowroom);
                if (showroomAdded == true)
                {
                    MessageBox.Show("Showroom record added successfully.");

                }
                else
                {
                    MessageBox.Show("Showroom record couldn't be added.");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Get All Showroom Data...........

        private void GetShowroom()
        {
            try
            {
                List<Showroom> objShowrooms = ShowroomBL.GetAllShowroomsBL();
                if (objShowrooms != null)
                {
                    dgShowroom.ItemsSource = objShowrooms;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //Get all Dealers for Dealer ID.............

        private void GetDealers()
        {
            try
            {
                List<Dealer> objdealers = DealerBL.GetAllDealersBL();
                if (objdealers != null)
                {
                    cmbDealerID.ItemsSource = objdealers;
                    cmbDealerID.SelectedValuePath = " DealerID";
                    cmbDealerID.DisplayMemberPath = "DealerName";
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
