﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVSR.Entities;
using OVSR.Exceptions;
using OVSR.BusinessLayer;

namespace OnlineVehicleShowroom
{
    /// <summary>
    /// Interaction logic for VehiclePL.xaml
    /// </summary>
    public partial class VehiclePL : Window
    {
        public VehiclePL()
        {
            InitializeComponent();
        }

        //Validation Part..............

        private bool ValidateUI()
        {
            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if (txtVehicleID.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Vehicle Id should not be Empty" + Environment.NewLine);
            }

            if (txtVehicleName.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Vehicle Name should not be Empty" + Environment.NewLine);
            }

            if (txtVehicleModel.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Vehicle model should not be Empty" + Environment.NewLine);
            }

            if (cmbDealerID.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Dealer ID should not be Empty" + Environment.NewLine);
            }
            if (txtCost.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Cost should not be Empty" + Environment.NewLine);
            }
            if (txtTotalstock.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Total Stock should not be Empty" + Environment.NewLine);
            }
            if (txtDescription.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Description should not be Empty" + Environment.NewLine);
            }
            if (txtrating.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Rating should not be Empty" + Environment.NewLine);
            }
            if (!isValid)
            {
                throw new OVSRException(sb.ToString());
            }
            return isValid;
        }

        //Butoon for Add............

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (ValidateUI())
                {
                    AddVehicle();
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }


            Clear();
        }

        //Button for List.............

        private void BtnList_Click(object sender, RoutedEventArgs e)
        {
            GetVehicles();
            Clear();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            UpdateVehicle();
            Clear();
        }

        //Button for Search...............

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchVehicle();
        }

        //butoon to get Main window.............

        private void Btnclear_Click(object sender, RoutedEventArgs e)
        {
            MainWindow win1 = new MainWindow();
            win1.Show();
            this.Close();
        }

        //Clear Method.....

        private void Clear()
        {
            txtVehicleID.Clear();
            txtVehicleName.Clear();
            txtVehicleModel.Clear();
            cmbDealerID.SelectedIndex=-1;
            txtCost.Clear();
            txtTotalstock.Clear();
            txtDescription.Clear();
            txtrating.Clear();
            
            dgVehicles.DataContext = null;
        }

        //Add Vehicle..............

        private void AddVehicle()
        {
            try
            {
                int vid;
                string vName;
                string vModel;
                int dealerID;
                double cost;
                int totalStock;
                string description;
                int rating;
              
                //
                bool vehicleAdded;

                vid = Convert.ToInt32(txtVehicleID.Text);
                vName = txtVehicleName.Text;
                vModel = txtVehicleModel.Text;
                dealerID =Convert.ToInt32(cmbDealerID.SelectedValue);
                cost =Convert.ToDouble(txtCost.Text);
                totalStock =Convert.ToInt32(txtTotalstock.Text);
                description = txtDescription.Text;
                rating = Convert.ToInt32(txtrating.Text);

                //
                Vehicle objvehicle = new Vehicle
                {
                    VehicleID = vid,
                    VehicleName = vName,
                    VehicleModel = vModel,
                    DealerID = dealerID,
                    Cost = cost,
                    TotalStock = totalStock,
                    Description = description,
                    Rating = rating
                    
                };
                vehicleAdded = VehicleBL.AddVehicleBL(objvehicle);
                if (vehicleAdded == true)
                {
                    MessageBox.Show("Vehicle record added successfully.");

                }
                else
                {
                    MessageBox.Show("Vehicle record couldn't be added.");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Update Vehicle..............

        private void UpdateVehicle()
        {
            try
            {
                int vid;
                string vName;
                string vModel;
                int dealerID;
                double cost;
                int totalStock;
                string description;
                int rating;

                //
                bool vehicleAdded;


                vid = Convert.ToInt32(txtVehicleID.Text);
                vName = txtVehicleName.Text;
                vModel = txtVehicleModel.Text;
                dealerID = Convert.ToInt32(cmbDealerID.SelectedValue);
                cost = Convert.ToDouble(txtCost.Text);
                totalStock = Convert.ToInt32(txtTotalstock.Text);
                description = txtDescription.Text;
                rating = Convert.ToInt32(txtrating.Text);

                //

                Vehicle objvehicle = new Vehicle
                {
                    VehicleID = vid,
                    VehicleName = vName,
                    VehicleModel = vModel,
                    DealerID = dealerID,
                    Cost = cost,
                    TotalStock = totalStock,
                    Description = description,
                    Rating = rating

                };
                vehicleAdded = VehicleBL.UpdateVehicleBL(objvehicle);
                if (vehicleAdded == true)
                {
                    MessageBox.Show("Vehicle record Updated successfully.");
                }
                else
                {
                    MessageBox.Show("Vehicle record couldn't be Updated.");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Search Vehicle..............

        private void SearchVehicle()
        {
            try
            {
                int vid;
                //
                Vehicle objVehicle;
                //
                vid = Convert.ToInt32(txtVehicleID.Text);
                //
                objVehicle = VehicleBL.SearchVehicleByIdBL(vid);
                if (objVehicle != null)
                {
                    txtVehicleName.Text = objVehicle.VehicleName;

                    txtVehicleModel.Text = objVehicle.VehicleModel;                   

                    cmbDealerID.SelectedValue = objVehicle.DealerID;

                    txtCost.Text =Convert.ToString(objVehicle.Cost);

                    txtTotalstock.Text =Convert.ToString(objVehicle.TotalStock);

                    txtDescription.Text = objVehicle.Description;

                    txtrating.Text = Convert.ToString(objVehicle.Rating);


                }
                else
                {
                    MessageBox.Show("Vehicle record couldn't be found.");
                }
            }
            catch (OVSRException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Get All Vehicles..............

        private void GetVehicles()
        {
            try
            {
                List<Vehicle> objvehicle = VehicleBL.GetAllVehiclesBL();
                if (objvehicle != null)
                {
                    dgVehicles.ItemsSource = objvehicle;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //Get all dealers for dealer ID....

        private void GetDealers()
        {
            try
            {
                List<Dealer> objdealers = DealerBL.GetAllDealersBL();
                if (objdealers != null)
                {
                    cmbDealerID.ItemsSource = objdealers;
                    cmbDealerID.DisplayMemberPath = "DealerID";
                    cmbDealerID.SelectedValuePath = " DealerID";
                    
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (OVSRException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //Window load fro foreign key constrain...

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDealers();
        }
    }
}
