				-------STORE PROCEDURE FOR VEHICLE------

------Add vehicle----
drop procedure [ar177501].USP_AddVehicle

create procedure [ar177501].USP_AddVehicle
@VehicleID int,
@VehicleName varchar(30),
@VehicleModel varchar(30),
@DealerID int,
@Cost varchar(50),
@TotalStock int,
@Description varchar(30),
@Rating int
AS
	insert into [ar177501].Vehicle values(@VehicleID,@VehicleName,@VehicleModel,@DealerID,@Cost,@TotalStock,@Description,@Rating)
RETURN 0

-------List All Vehicles----

create procedure [ar177501].USP_ListAllVehicles
AS 
BEGIN
select * from [ar177501].Vehicle
END

-----Search vehicle by ID --------

drop procedure [ar177501].USP_SearchVehicleById

ALTER procedure [ar177501].[USP_SearchVehicleById]
	@VehicleID int ,
	@VehicleName varchar(30) out,
	@VehicleModel varchar(30) out,
	@DealerID int out,
	@Cost varchar(50) out,
	@TotalStock int out,
	@Description varchar(30) out,
	@Rating int out,
	@VehicleExists int out
As 

BEGIN
	if(exists(select vehicleid from [ar177501].Vehicle where vehicleid =  @VehicleID))
	Begin
		select
			@VehicleName=VehicleName ,
			@VehicleModel=VehicleModel ,
			@DealerID=DealerID ,
			@Cost =Cost,
			@TotalStock=TotalStock ,
			@Description=Description ,
			@Rating=Rating 
	from [ar177501].Vehicle 
		Where VehicleID=@VehicleID
		set @VehicleExists = 1;
	End
	Else
	Begin
	set @VehicleExists =2
	end
	select @VehicleExists as VehicleExists
END

----Update Vehicle----

drop procedure [ar177501].USP_UpdateVehicle

create procedure [ar177501].USP_UpdateVehicle
	@VehicleID int,
	@VehicleName varchar(30),
	@VehicleModel varchar(30),
	@DealerID int,
	@Cost varchar(50),
	@TotalStock int,
	@Description varchar(30),
	@Rating int
As 
	update [ar177501].Vehicle set VehicleName=@VehicleName,VehicleModel=@VehicleModel,DealerID=@DealerID,Cost=@Cost,TotalStock=@TotalStock,Description=@Description,rating=@Rating
	Where VehicleID=@VehicleID
RETURN 0

