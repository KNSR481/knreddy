						---STORE PROCEDURES FOR CUSTOMER TABLE------



--store procedure for add customer--
drop procedure [ar177501].USP_AddCustomer

create procedure [ar177501].USP_AddCustomer
@CustomerID int,
@CustomerName varchar(30),
@Gender varchar(20),
@ContactNO varchar(30),
@Email varchar(30),
@Address varchar(50),
@City varchar(20),
@State varchar(20),
@Pincode int
AS 
	insert into [ar177501].Customer values(@CustomerID,@CustomerName,@Gender,@ContactNO,@Email,@Address,@City,@State,@Pincode)
RETURN 0

--Store procedure for List customers--

create procedure [ar177501].USP_ListAllCustomers
AS 
BEGIN
select * from [ar177501].Customer
END

--SP for Search cutomer by ID---
drop procedure [ar177501].SearchCustomerByID

create procedure [ar177501].SearchCustomerByID
@customerID int,
@customerName varchar(30) out,
@gender varchar(20) out,
@contactNO varchar(30) out,
@email varchar(30) out,
@address varchar(50) out,
@city varchar(20) out,
@state varchar(20) out,
@pincode int out,
@customerexists int out
AS 
BEGIN
	if(exists(select CustomerID from [ar177501].Customer where customerid =  @customerID))
		Begin
			select
			@customerName=CustomerName,
			@gender= Gender,
			@contactNO=ContactNO ,
			@email=Email ,
			@address=Address,
			@city =City,
			@state= State,
			@pincode=Pincode
			from [ar177501].Customer
			where
				CustomerID=@customerId 
				set @customerexists = 1;
				End
	Else
	Begin
	set @customerexists =2
	end
	select @customerexists as customerexists
end


-----update store procedure for customer----
drop procedure [ar177501].USP_UpdateCustomer

create procedure [ar177501].USP_UpdateCustomer
@customerID int,
@customerName varchar(30),
@gender varchar(20),
@contactNO varchar(30),
@email varchar(30),
@address varchar(50),
@city varchar(20),
@state varchar(20),
@pincode int
AS
	update  [ar177501].Customer set CustomerName=@customerName,Gender=@gender,ContactNO=@contactNO,Email=@email,Address=@address,City=@city,State=@state,Pincode=@pincode 	
	where CustomerID=@customerID

RETURN 0


