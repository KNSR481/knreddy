			-------STOREPROCEDURES FOR SALES -----------

-----Add sales Data-------
drop procedure [ar177501].USP_AddSales

create procedure [ar177501].USP_AddSales

@SalesID int,
@VehicleID int,
@CustomerID int,
@ShowroomID int,
@Cost int,
@OrderDate Datetime,
@DeliveryDate Datetime,
@Remarks varchar(30)
AS
	insert into [ar177501].Sales values(@SalesID,@VehicleID,@CustomerID,@ShowroomID,@Cost,@OrderDate,@DeliveryDate,@Remarks)
RETURN 0

------Get all sales Data-----

create procedure [ar177501].USP_ListAllSales
As
	Begin
	Select * from [ar177501].Sales
END
