					------STOREPROCEDURE FOR SHOWROOM----

-----ADD------
drop procedure [ar177501].USP_AddShowroom

create procedure [ar177501].USP_AddShowroom
@ShowroomID int  ,
@ShowroomName varchar(30),
@DealerID int,
@OwnerName varchar(30),
@ContactNO varchar(30),
@Address varchar(30),
@City varchar(30),
@State varchar (20),
@Pincode int
AS 
	insert into [ar177501].Showroom values(@ShowroomID,@ShowroomName,@DealerID,@OwnerName,@ContactNO,@Address,@City,@State,@Pincode)
RETURN 0

------List All Showroom details----

Create procedure [ar177501].USP_ListAllShowroom
As
	BEGIN
	Select * from [ar177501].Showroom
END

