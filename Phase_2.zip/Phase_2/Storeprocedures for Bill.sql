------store Procedure for BILL------------


--------Generate Bill-----------
drop procedure [ar177501].USP_GenerateBill
 
Create Procedure [ar177501].USP_GenerateBill
	@salesid  int,
	@vehicleid int output,
	@customername varchar(100) output,
	@showroomid int output,
	@cost varchar(50) output,
	@orderdate datetime output,
	@deliverydate datetime output
as
	SELECT @vehicleid=[ar177501].Sales.VehicleID,@customername=[ar177501].Customer.CustomerName,@showroomid=[ar177501].Sales.ShowroomID,@cost=[ar177501].Sales.Cost,@orderdate=[ar177501].Sales.OrderDate,@deliverydate=[ar177501].Sales.DeliveryDate
	FROM  [ar177501].Sales
	LEFT JOIN [ar177501].Customer
	ON [ar177501].Sales.CustomerID = [ar177501].Customer.CustomerID
	where  [ar177501].Sales.SalesID=@salesid
return 0
     

-------------Get all Bill-----------


create procedure [ar177501].GetAllBill
AS 
BEGIN
select * from [ar177501].Bill
END

----------Add Bill--------------

drop procedure [ar177501].AddBill

CREATE PROCEDURE [ar177501].AddBill
	@salesid int,
	@quantity int,
	@vehicleid int,
	@customername varchar(100),
	@showroomid int,
	@cost varchar(50),
	@orderdate datetime,
	@deliverydate datetime
AS
	insert into [ar177501].Bill values(@salesid,@quantity,@vehicleid,@customername,@showroomid,@cost,@orderdate,@deliverydate)
	declare @billid int
	set @billid=SCOPE_IDENTITY()
RETURN @billid

----------Generate Purchase Data Using Bill Details-----------

create procedure [ar177501].PurchaseData
@billID int,
@salesid int out,
@quantity int out,
@vehicleid varchar(20) out,
@customername varchar(30) out,
@showroomid varchar(30) out,
@cost varchar(50) out,
@orderdate varchar(20) out,
@deliverydate varchar(20) out,
@billexists int out
AS 
BEGIN
	if(exists(select BillID from [ar177501].Bill where billID =  @billID))
		Begin
			select
			@salesid=SalesID,
			@quantity= Quantity,
			@vehicleid=VehicleID ,
			@customername=CustomerName ,
			@showroomid=ShowroomID,
			@cost =Cost,
			@orderdate= OrderDate,
			@deliverydate=DeliveryDate
			from [ar177501].Bill
			where
				billID=@billID 
				set @billexists = 1;
				End
	Else
	Begin
	set @billexists =2
	end
	select @billexists as billexists
end
