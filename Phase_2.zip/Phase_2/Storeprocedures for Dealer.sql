				----STOREPROCEDURES FOR DEALER-----

-----ADD-------
drop procedure [ar177501].USP_Adddealer

create procedure [ar177501].USP_Adddealer
@DealerID int ,
@DealerName varchar(30),
@CompanyName varchar(30),
@Address varchar(30),
@ContactNO varchar(30),
@City varchar(30),
@State varchar(30),
@Pincode int
AS
	insert into [ar177501].Dealer values(@DealerID,@DealerName,@CompanyName,@Address,@ContactNO,@City,@State,@Pincode)
RETURn 0

----List All Dealer---

create procedure [ar177501].USP_ListAllDealer
AS 
BEGIN
select * from [ar177501].Dealer
END


select * from [ar177501].Dealer