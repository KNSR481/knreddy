drop table [ar177501].Customer

create table [ar177501].Customer
(
CustomerID int primary key,
CustomerName varchar(30),
Gender varchar(20),
ContactNO varchar(30),
Email varchar(30),
Address varchar(50),
City varchar(20),
State varchar(20),
Pincode int

)

select * from [ar177501].Customer

---DEALER TABLE-----

drop table  [ar177501].Dealer

create table [ar177501].Dealer
(
DealerID int primary key,
DealerName varchar(30),
CompanyName varchar(30),
Address varchar(30),
ContactNO varchar(30),
City varchar(30),
State varchar(30),
Pincode int
)

insert  into [ar177501].Dealer values(101,'Aruna','KIA','ATP',9618031619,'Atp','AP',789456)

select * from [ar177501].Dealer

-----Vehicle table------

drop table [ar177501].Vehicle

create table [ar177501].Vehicle
(
VehicleID int primary key,
VehicleName varchar(30),
VehicleModel varchar(30),
DealerID int foreign key references [ar177501].Dealer(DealerID),
Cost varchar(30),
TotalStock int,
Description varchar(30),
Rating int
)

insert into [ar177501].Vehicle values(111,'Kia','Z5',101,500000,20,'Good',9)

--insert into [ar177501].Vehicle values(222,'Kia','Z5',102,500000,20,'Good',9)

select * from [ar177501].Vehicle

------Showroom table------

drop table [ar177501].Showroom

create table [ar177501].Showroom
(
ShowroomID int primary key,
ShowroomName varchar(30),
DealerID int foreign key references [ar177501].Dealer(DealerID),
OwnerName varchar(30),
ContactNO varchar(30),
Address varchar(30),
City varchar(30),
State varchar (20),
Pincode int
)

select * from [ar177501].Showroom
delete from [ar177501].Showroom where ShowroomID=123;
------sales-------

drop table [ar177501].Sales


create table [ar177501].Sales
(
SalesID int primary key,
VehicleID int foreign key references [ar177501].Vehicle(VehicleID),
CustomerID int foreign key references [ar177501].Customer(CustomerID),
ShowroomID int foreign key references [ar177501].Showroom(ShowroomID),
Cost int,
OrderDate Datetime,
DeliveryDate Datetime,
Remarks varchar(30)
)

select * from [ar177501].Sales

--------------BILL TABLE--------------

drop table [ar177501].Bill

create table [ar177501].Bill
(
	BillId int primary key identity(100,1),
	SalesId int foreign key references [ar177501].Sales(SalesID), 
	Quantity int,
	VehicleId int,
	CustomerName varchar(100),
	ShowroomId int,
	Cost varchar(50),
	OrderDate datetime,
	DeliveryDate datetime
)

select * from [ar177501].Bill

insert into [ar177501].Bill values(111,111,5,111,895623,'9/8/2000','5/6/2015')


