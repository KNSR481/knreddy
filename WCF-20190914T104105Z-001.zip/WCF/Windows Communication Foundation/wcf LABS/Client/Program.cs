﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel.Description;
using System.ServiceModel;
namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            CalculatorServiceReference.MathsClient proxy = new 
                CalculatorServiceReference.MathsClient();
            Console.WriteLine(proxy.Add(10, 10));
            Console.WriteLine(proxy.Multiply(10, 10));
            Console.Read();
        }
    }
}
