﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Contract
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Maths" in both code and config file together.
    public class Maths : IMaths
    {
        public int Add(int num1, int num2)
        {
            return num1 + num2;
        }

        public int Multiply(int num1, int num2)
        {
            return num1 * num2;
        }

        public void Logout()
        {                

            //do some activity.. it may take time .. but it is one way.. fire & forget             
            System.Threading.Thread.Sleep(5000);   
        }
    }
}