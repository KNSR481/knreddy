﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contract;
using System.ServiceModel.Description;
using System.ServiceModel;
namespace Host
{
    class Program
    {
        static void Main(string[] args)
        {

            ServiceHost host = new ServiceHost(typeof(CalculateReference.IMaths),
                new Uri("http://localhost:8080/Maths"),
                new Uri("net.tcp://localhost:8081/Maths"));
            host.Open();
            host.AddServiceEndpoint(typeof(CalculateReference.IMaths),
                new WSHttpBinding(), "myendpoint");

            host.AddDefaultEndpoints();
            foreach (ServiceEndpoint se in host.Description.Endpoints)
                Console.WriteLine("A: {0}, B: {1}, C: {2}", se.Address, se.Binding.Name, se.Contract.Name);
            Console.WriteLine("Press <Enter> to stop the service.");
            Console.ReadLine();
            host.Close();
        }
    }
}
