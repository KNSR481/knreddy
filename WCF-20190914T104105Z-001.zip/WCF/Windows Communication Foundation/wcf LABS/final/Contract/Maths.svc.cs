﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Contract
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Maths" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Maths.svc or Maths.svc.cs at the Solution Explorer and start debugging.
    public class Maths : IMaths
    {
        public int Add(int num1, int num2)
        {
            return num1 + num2;
        }

        public int Multiply(int num1, int num2)
        {
            return num1 * num2;
        }

        public void Logout()
        {        
            //do some activity.. it may take time .. but it is one way.. fire & forget           
            System.Threading.Thread.Sleep(5000);             } 


        }
    }
