﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class CustomerBL
    {
        private static bool validateCustomer(Customer customer)
        {
            StringBuilder sb = new StringBuilder();
            bool validCustomer = true;


            if (validCustomer == false)
            {
                throw new OVSRException(sb.ToString());
            }

            return validCustomer;
        }


        public static bool AddCustomerBL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
             if(validateCustomer(newCustomer))
                {
                    CustomerDAL customerDAL = new CustomerDAL();
                    customerAdded = customerDAL.AddCustomerDAL(newCustomer);
                }

            }
            catch (OVSRException)
            {

                throw;
            }

            return customerAdded;
        }


        public static List<Customer> GetAllCustomersBL()
        {
            List<Customer> customerList = null;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();
                customerList = customerDAL.GetAllCustomerDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customerList;
        }

        public static Customer SearchCustomerBL(int searchCustomerID)
        {
            Customer searchCustomer = null;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();
                searchCustomer = customerDAL.SearchCustomerDAL(searchCustomerID);
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCustomer;

        }

        public static bool UpdateCustomerBL(Customer updateCustomer)
        {
            bool customerUpdated = false;
            try
            {
                if (validateCustomer(updateCustomer))
                {
                    CustomerDAL customerDAL = new CustomerDAL();
                    customerUpdated = customerDAL.UpdateCustomerDAL(updateCustomer);
                }
            }
            catch (OVSRException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return customerUpdated;
        }






    }
}
