﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class DealerBL
    {
        private static bool validateDealer(Dealer dealer)
        {
            StringBuilder sb = new StringBuilder();
            bool validDealer = true;


            if (validDealer == false)
            {
                throw new OVSRException(sb.ToString());
            }

            return validDealer;
        }


        public static bool AddDealerBL(Dealer newDealer)
        {
            bool DealerAdded = false;
            try
            {
                if (validateDealer(newDealer))
                {
                    DealerDAL dealerDAL = new DealerDAL();
                    DealerAdded = dealerDAL.AddDealerDAL(newDealer);
                }

            }
            catch (OVSRException)
            {

                throw;
            }

            return DealerAdded;
        }



        public static List<Dealer> GetAllDealersBL()
        {
            List<Dealer> dealerList = null;
            try
            {
                DealerDAL dealerDAL = new DealerDAL();
                dealerList = dealerDAL.GetAllDealerDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dealerList;
        }


    }
}
