﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class SalesBL
    {
        private static bool validateSales(Sales sales)
        {
            StringBuilder sb = new StringBuilder();
            bool validSales = true;


            if (validSales == false)
            {
                throw new OVSRException(sb.ToString());
            }

            return validSales;
        }


        public static bool AddSalesBL(Sales newSales)
        {
            bool SalesAdded = false;
            try
            {
                if (validateSales(newSales))
                {
                    SalesDAL salesDAL = new SalesDAL();
                    SalesAdded = salesDAL.AddSalesDAL(newSales);
                }

            }
            catch (OVSRException)
            {

                throw;
            }

            return SalesAdded;
        }

        public static List<Sales> GetAllSalesBL()
        {
            List<Sales> salesList = null;
            try
            {
                SalesDAL salesDAL = new SalesDAL();
                salesList = salesDAL.GetAllSalesDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return salesList;
        }
    }
}
