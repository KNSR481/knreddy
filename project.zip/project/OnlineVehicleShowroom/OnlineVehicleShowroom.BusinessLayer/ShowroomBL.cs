﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class ShowroomBL
    {
        private static bool validateShowroom(Showroom showroom)
        {
            StringBuilder sb = new StringBuilder();
            bool validShowroom = true;


            if (validShowroom == false)
            {
                throw new OVSRException(sb.ToString());
            }

            return validShowroom;
        }


        public static bool AddShowroomBL(Showroom newShowroom)
        {
            bool ShowroomAdded = false;
            try
            {
                if (validateShowroom(newShowroom))
                {
                    ShowroomDAL showroomDAL = new ShowroomDAL();
                    ShowroomAdded = showroomDAL.AddShowroomDAL(newShowroom);
                }

            }
            catch (OVSRException)
            {

                throw;
            }

            return ShowroomAdded;
        }

        public static List<Showroom> GetAllShowroomBL()
        {
            List<Showroom> showroomList = null;
            try
            {
                ShowroomDAL showroomDAL = new ShowroomDAL();
                showroomList = showroomDAL.GetAllShowroomDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return showroomList;
        }
    }
}
