﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.DataAccessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.BusinessLayer
{
    public class VehicleBL
    {
        private static bool validateVehicle(Vehicle vehicle)
        {
            StringBuilder sb = new StringBuilder();
            bool validVehicle = true;


            if (validVehicle == false)
            {
                throw new OVSRException(sb.ToString());
            }

            return validVehicle;
        }


        public static bool AddVehicleBL(Vehicle newvehicle)
        {
            bool vehicleAdded = false;
            try
            {
                if (validateVehicle(newvehicle))
                {
                    VehicleDAL vehicleDAL = new VehicleDAL();
                    vehicleAdded = vehicleDAL.AddVehicleDAL(newvehicle);
                }

            }
            catch (OVSRException)
            {

                throw;
            }

            return vehicleAdded;
        }

        public static List<Vehicle> GetAllVehicleBL()
        {
            List<Vehicle> vehicleList = null;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                vehicleList = vehicleDAL.GetAllVehicleDAL();
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return vehicleList;
        }

        public static Vehicle SearchVehicleByIdBL(int searchVehicleID)
        {
            Vehicle searchVehicle = null;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                searchVehicle = vehicleDAL.SearchVehicleByIdDAL(searchVehicleID);
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVehicle;

        }

        public static Vehicle SearchVehicleByNameBL(string searchVehicleName)
        {
            Vehicle searchVehicle = null;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                searchVehicle = vehicleDAL.SearchVehicleByNameDAL(searchVehicleName);
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVehicle;

        }

        public static Vehicle SearchVehicleByModelBL(string searchVehicleModel)
        {
            Vehicle searchVehicle = null;
            try
            {
                VehicleDAL vehicleDAL = new VehicleDAL();
                searchVehicle = vehicleDAL.SearchVehicleByModelDAL(searchVehicleModel);
            }
            catch (OVSRException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVehicle;

        }


        public static bool UpdateVehicleBL(Vehicle updateVehicle)
        {
            bool vehicleUpdated = false;
            try
            {
                if (validateVehicle(updateVehicle))
                {
                    VehicleDAL vehicleDAL = new VehicleDAL();
                    vehicleUpdated = vehicleDAL.UpdateVehicleDAL(updateVehicle);
                }
            }
            catch (OVSRException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return vehicleUpdated;
        }
    }
}
