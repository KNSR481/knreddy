﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.DataAccessLayer
{
    public class DealerDAL
    {
        public static List<Dealer> dealerList = new List<Dealer>();

        public List<Dealer> GetAllDealerDAL()
        {
            return dealerList;
        }

        public bool AddDealerDAL(Dealer newDealer)
        {
            bool dealerAdded = false;
            try
            {
                dealerList.Add(newDealer);             
                dealerAdded = true;
            }
            catch (SystemException e)
            {
                throw new OVSRException(e.Message);
            }
            return dealerAdded;
        }
    }

}
