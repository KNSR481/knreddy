﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.DataAccessLayer
{
    public class SalesDAL
    {
        public static List<Sales> salesList = new List<Sales>();

        public List<Sales> GetAllSalesDAL()
        {
            return salesList;
        }

        public bool AddSalesDAL(Sales newSales)
        {
            bool SalesAdded = false;
            try
            {
                salesList.Add(newSales);            
                SalesAdded = true;
            }
            catch (SystemException e)
            {
                throw new OVSRException(e.Message);
            }
            return SalesAdded;
        }
    }
}
