﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom.DataAccessLayer
{
    public class ShowroomDAL
    {

        public static List<Showroom> showroomList = new List<Showroom>();

        public List<Showroom> GetAllShowroomDAL()
        {
            return showroomList;
        }

        public bool AddShowroomDAL(Showroom newShowroom)
        {
            bool ShowroomAdded = false;
            try
            {
                showroomList.Add(newShowroom);              
                ShowroomAdded = true;
            }
            catch (SystemException e)
            {
                throw new OVSRException(e.Message);
            }
            return ShowroomAdded;
        }
    }
}
