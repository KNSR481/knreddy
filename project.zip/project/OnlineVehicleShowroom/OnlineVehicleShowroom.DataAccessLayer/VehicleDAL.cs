﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;


namespace OnlineVehicleShowroom.DataAccessLayer
{
    public class VehicleDAL
    {
        public static List<Vehicle> vehicleList = new List<Vehicle>();

        public List<Vehicle> GetAllVehicleDAL()
        {
            return vehicleList;
        }

        public bool AddVehicleDAL(Vehicle newVehicle)
        {
            bool vehicleAdded = false;
            try
            {
                vehicleList.Add(newVehicle);             
                vehicleAdded = true;
            }
            catch (SystemException e)
            {
                throw new OVSRException(e.Message);
            }
            return vehicleAdded;
        }

        public bool UpdateVehicleDAL(Vehicle updateVehicle)
        {
            bool vehicleUpdated = false;
            try
            {
                for (int i = 0; i < vehicleList.Count; i++)
                {
                    if (vehicleList[i].VehicleID == updateVehicle.VehicleID)
                    {
                        updateVehicle.VehicleName = vehicleList[i].VehicleName;
                        updateVehicle.VehicleModel = vehicleList[i].VehicleModel;
                        updateVehicle.DealerID = vehicleList[i].DealerID;
                        updateVehicle.Cost = vehicleList[i].Cost;
                        updateVehicle.TotalStock = vehicleList[i].TotalStock;
                        updateVehicle.Description = vehicleList[i].Description;
                        updateVehicle.Rating = vehicleList[i].Rating;

                        vehicleUpdated = true;
                    }
                }

            }
            catch (SystemException e)
            {
                throw new OVSRException(e.Message);
            }
            return vehicleUpdated;
        }

        public Vehicle SearchVehicleByIdDAL(int searchVehicleID)
        {
            Vehicle searchVehicle = null;
            try
            {
                searchVehicle = vehicleList.Find(vehicle => vehicle.VehicleID == searchVehicleID);
            }
            catch (SystemException e)
            {
                throw new OVSRException(e.Message);
            }
            return searchVehicle;
        }

        public Vehicle SearchVehicleByNameDAL(string searchVehicleName)
        {
            Vehicle searchVehicle = null;
            try
            {
                searchVehicle = vehicleList.Find(vehicle => vehicle.VehicleName == searchVehicleName);
            }
            catch (SystemException e)
            {
                throw new OVSRException(e.Message);
            }
            return searchVehicle;
        }

        public Vehicle SearchVehicleByModelDAL(string searchVehicleModel)
        {
            Vehicle searchVehicle = null;
            try
            {
                searchVehicle = vehicleList.Find(vehicle => vehicle.VehicleModel == searchVehicleModel);
            }
            catch (SystemException e)
            {
                throw new OVSRException(e.Message);
            }
            return searchVehicle;
        }

    }
}
