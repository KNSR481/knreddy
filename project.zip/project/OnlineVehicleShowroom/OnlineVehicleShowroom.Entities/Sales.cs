﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineVehicleShowroom.Entities
{
    public class Sales
    {
        private int salesID; 
        private  int vehicleID;
        private int customerID;
        private int showroomID;
        private double cost;
        private DateTime orderDate;
        private DateTime deliveryDate;
        private string remarks;
      
        public int SalesID { get; set; }
        public int VehicleID { get; set; }
        public int CustomerID { get; set; }
        public int ShowroomID { get; set; }
        public double Cost { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string Remarks { get; set; }


    }
}
