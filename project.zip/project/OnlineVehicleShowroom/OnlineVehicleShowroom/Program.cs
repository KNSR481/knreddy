﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineVehicleShowroom.BusinessLayer;
using OnlineVehicleShowroom.Entities;
using OnlineVehicleShowroom.Exceptions;

namespace OnlineVehicleShowroom
{
    class Program
    {
        static void Main(string[] args)
        {

           int choice;
           char c;
           do
           {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
               choice = Convert.ToInt32(Console.ReadLine());
               switch (choice)
               {
                   case 1:
                        AddCustomer();
                        break;
                    case 2:
                        ListAllCustomers();
                        break;
                    case 3:
                       SearchCustomerByID();
                       break;
                   case 4:
                       UpdateCustomer();
                       break;
                   case 5:
                        AddDealer();
                        break;
                    case 6:
                        ListAllDealers();
                        break;
                    case 7:
                        AddVehicle();
                        break;
                    case 8:
                        ListVehicles();
                        break;
                    case 9:
                        SearchVehicleById();
                        break;
                    case 10:
                        SearchVehicleByName();
                        break;
                    case 11:
                        SearchVehicleByModel();
                        break;
                    case 12:
                        UpdateVehicle();
                        break;
                    case 13:
                        AddShowroomData ();
                        break;
                    case 14:
                        GetAllShowroomDetails();
                        break;
                    case 15:
                        AddSalesData();
                        break;
                    case 16:
                        GetAllSalesDetails();
                        break;
                    case 17:
                        Environment.Exit(0);
                        break;

                   default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("Do you Want to Continue? 'y' to continue and 'n' to exit.");
                c = Convert.ToChar(Console.ReadLine());
           } while (c == 'y');
        }


        private static void PrintMenu()
        {
            Console.WriteLine("\n=======================Customer Details Menu==========================");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. List All Customers");
            Console.WriteLine("3. Search Customer by ID");
            Console.WriteLine("4. Update Customer");
            Console.WriteLine("5. Add Dealer Details");
            Console.WriteLine("6. List All Dealers");
            Console.WriteLine("7. Add Vehicle Details");
            Console.WriteLine("8. Get All Vehicle Details");
            Console.WriteLine("9. Search Vehicle By ID");
            Console.WriteLine("10. Search Vehicle By Name");
            Console.WriteLine("11. Search Vehicle By Model");
            Console.WriteLine("12. Update Vehicle By ID");
            Console.WriteLine("13. Add Showroom Details");
            Console.WriteLine("14. Get All Showroom Detaila");
            Console.WriteLine("15. Add Sales Details");
            Console.WriteLine("16. Get All Sales Details ");
            Console.WriteLine("17. Exit");
            Console.WriteLine("==============================================================================\n");

        }


        private static void AddCustomer()
        {
            try
            {
                Customer newCustomer = new Customer();
                Console.WriteLine("Enter CustomerID :");
                newCustomer.CustomerID = Convert.ToInt32(Console.ReadLine());


                Console.WriteLine("Enter Customer Name :");
                newCustomer.CustomerName = Console.ReadLine();

                Console.WriteLine("Enter Customer Gender :");
                newCustomer.Gender = Console.ReadLine();

                Console.WriteLine("Enter ContactNo:");
                newCustomer.ContactNo = Console.ReadLine();

                Console.WriteLine("Enter Address:");
                newCustomer.Address = Console.ReadLine();

                Console.WriteLine("Enter City:");
                newCustomer.City = Console.ReadLine();

                Console.WriteLine("Enter State:");
                newCustomer.State = Console.ReadLine();

                Console.WriteLine("Enter Pincode:");
                newCustomer.Pincode = Convert.ToInt32(Console.ReadLine());

                bool customerAdded = CustomerBL.AddCustomerBL(newCustomer);
                if (customerAdded)
                    Console.WriteLine("Customer Added");
                else
                    Console.WriteLine("Customer not Added");
            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchCustomerByID()
        {
            try
            {
                int searchCustomerID;
                Console.WriteLine("Enter CustomerID to Search:");
                searchCustomerID = Convert.ToInt32(Console.ReadLine());
                Customer searchCustomer = CustomerBL.SearchCustomerBL(searchCustomerID);
                if (searchCustomer != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("CustomerID\t\tCustomerName\t\tGender\t\tContactNO\t\tAddress\t\tCity\t\tState\t\tPincode");
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchCustomer.CustomerID, searchCustomer.CustomerName, searchCustomer.Gender, searchCustomer.ContactNo, searchCustomer.Address, searchCustomer.City, searchCustomer.State, searchCustomer.Pincode);
                    Console.WriteLine("==============================================================================");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }

            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateCustomer()
        {
            try
            {
                int updateCustomerID;
                Console.WriteLine("Enter Customer ID to Update Details:");
                updateCustomerID = Convert.ToInt32(Console.ReadLine());
                Customer updatedCustomer = CustomerBL.SearchCustomerBL(updateCustomerID);
                if (updatedCustomer != null)
                {
                    Console.WriteLine("Update Customer Name :");
                    updatedCustomer.CustomerName = Console.ReadLine();
                    Console.WriteLine("Update Gender :");
                    updatedCustomer.Gender = Console.ReadLine();
                    Console.WriteLine("Update ContactNO. :");
                    updatedCustomer.ContactNo = Console.ReadLine();
                    Console.WriteLine("Update Address:");
                    updatedCustomer.Address = Console.ReadLine();
                    Console.WriteLine("Update City :");
                    updatedCustomer.City = Console.ReadLine();
                    Console.WriteLine("Update State :");
                    updatedCustomer.State = Console.ReadLine();
                    Console.WriteLine("Update Pincode :");
                    updatedCustomer.Pincode = Convert.ToInt32(Console.ReadLine());

                    bool customerUpdated = CustomerBL.UpdateCustomerBL(updatedCustomer);
                    if (customerUpdated)
                        Console.WriteLine("Customer Details Updated");
                    else
                        Console.WriteLine("Customer Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }


            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void ListAllCustomers()

            {
                try
                {
                    List<Customer> customerList = CustomerBL.GetAllCustomersBL();
                    if (customerList != null)
                    {
                        Console.WriteLine("==============================================================================");
                        Console.WriteLine("CustomerID\t\tCustomerName\t\tGender\t\tContactNO\t\tEmail\t\tAddress\t\tCity\t\tState\t\tPincode");
                        Console.WriteLine("==============================================================================");
                        foreach (Customer customer in customerList)
                        {
                            Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}", customer.CustomerID, customer.CustomerName, customer.Gender, customer.ContactNo,customer.Email,customer.Address, customer.City, customer.State, customer.Pincode);
                        }
                        Console.WriteLine("==============================================================================");

                    }
                    else
                    {
                        Console.WriteLine("No Guest Details Available");
                    }
                }
                catch (OVSRException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }


        private static void AddDealer()
        {
            try
            {
                Dealer newDealer = new Dealer();
                Console.WriteLine("Enter DealerID :");
                newDealer.DealerID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Dealer Name :");
                newDealer.DealerName = Console.ReadLine();
                Console.WriteLine("Enter Company Name :");
                newDealer.CompanyName = Console.ReadLine();
                Console.WriteLine("Enter Address:");
                newDealer.Address = Console.ReadLine();
                Console.WriteLine("Enter Contact NO. :");
                newDealer.ContactNo = Console.ReadLine();
                Console.WriteLine("Enter City :");
                newDealer.City = Console.ReadLine();
                Console.WriteLine("Enter State :");
                newDealer.State = Console.ReadLine();
                Console.WriteLine("Enter Pincode :");
                newDealer.Pincode =Convert.ToInt32(Console.ReadLine());

                bool dealerAdded = DealerBL.AddDealerBL(newDealer);
                if (dealerAdded)
                    Console.WriteLine("Dealer  Added");
                else
                    Console.WriteLine("Dealer not Added");
            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllDealers()
        {
            try
            {
                List<Dealer> dealerList = DealerBL.GetAllDealersBL();
                if (dealerList != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("DealerID\t\tDealerName\t\tCompanyName\t\tContactNO\t\tAddress\t\tCity\t\tState\t\tPincode");
                    Console.WriteLine("==============================================================================");
                    foreach (Dealer dealer in dealerList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}s", dealer.DealerID, dealer.DealerName, dealer.CompanyName, dealer.ContactNo,dealer.Address, dealer.City, dealer.State, dealer.Pincode);
                    }
                    Console.WriteLine("==============================================================================");

                }
                else
                {
                    Console.WriteLine("No Dealer Details Available");
                }
            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void AddVehicle()
        {
            try
            {
                Vehicle newVehicle = new Vehicle();
                Console.WriteLine("Enter Vehicle ID :");
                newVehicle.VehicleID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Vehicle Name :");
                newVehicle.VehicleName = Console.ReadLine();
                Console.WriteLine("Enter Vehicle Model :");
                newVehicle.VehicleModel = Console.ReadLine();
                Console.WriteLine("Enter Dealer ID:");
                newVehicle.DealerID =Convert.ToInt32( Console.ReadLine());
                Console.WriteLine("Enter Cost :");
                newVehicle.Cost = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter Total Stock :");
                newVehicle.TotalStock = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Description :");
                newVehicle.Description = Console.ReadLine();
                Console.WriteLine("Enter Rating :");
                newVehicle.Rating = Convert.ToInt32(Console.ReadLine());


                bool vehicleAdded = VehicleBL.AddVehicleBL(newVehicle);
                if (vehicleAdded)
                    Console.WriteLine("Vehicle Added");
                else
                    Console.WriteLine("Vehicle not Added");
            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateVehicle()
        {
            try
            {
                int updateVehicleID;
                Console.WriteLine("Enter Vehicle ID to Update Details:");
                updateVehicleID = Convert.ToInt32(Console.ReadLine());
                Vehicle updatedVehicle = VehicleBL.SearchVehicleByIdBL(updateVehicleID);
                if (updatedVehicle != null)
                {
                    Console.WriteLine("Update Vehicle Name :");
                    updatedVehicle.VehicleName = Console.ReadLine();
                    Console.WriteLine("Update Vehicle Model :");
                    updatedVehicle.VehicleModel = Console.ReadLine();
                    Console.WriteLine("Update Dealer ID. :");
                    updatedVehicle.DealerID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Update Cost:");
                    updatedVehicle.Cost = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Update Total Stock :");
                    updatedVehicle.TotalStock = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Update Description :");
                    updatedVehicle.Description = Console.ReadLine();
                    Console.WriteLine("Update Rating :");
                    updatedVehicle.Rating = Convert.ToInt32(Console.ReadLine());

                    bool vehicleUpdated = VehicleBL.UpdateVehicleBL(updatedVehicle);
                    if (vehicleUpdated)
                        Console.WriteLine("Vehicle Details Updated");
                    else
                        Console.WriteLine("Vehicle Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Vehicle Details Available");
                }


            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void ListVehicles()
        {
            try
            {
                List<Vehicle> vehicleList = VehicleBL.GetAllVehicleBL();
                if (vehicleList != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("VehicleID\t\tVehicle Name\t\tVehicle Model\t\tDealer ID\t\tCost\t\tTotal Stock\t\tDescription\t\tRating");
                    Console.WriteLine("==============================================================================");
                    foreach (Vehicle vehicle in vehicleList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}", vehicle.VehicleID, vehicle.VehicleName, vehicle.VehicleModel, vehicle.DealerID, vehicle.Cost, vehicle.TotalStock, vehicle.Description,vehicle.Rating);
                    }
                    Console.WriteLine("==============================================================================");

                }
                else
                {
                    Console.WriteLine("No Vehicle Details Available");
                }
            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchVehicleById()
        {
            try
            {
                int searchVehicleID;
                Console.WriteLine("Enter Vehicle ID to Search:");
                searchVehicleID = Convert.ToInt32(Console.ReadLine());
                Vehicle searchVehicle = VehicleBL.SearchVehicleByIdBL(searchVehicleID);
                if (searchVehicle != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("VehicleID\t\tVehicle Name\t\tVehicle Model\t\tDealer ID\t\tCost\t\tTotal Stock\t\tDescription\t\tRating");
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}", searchVehicle.VehicleID, searchVehicle.VehicleName, searchVehicle.VehicleModel, searchVehicle.DealerID, searchVehicle.Cost, searchVehicle.TotalStock, searchVehicle.Description, searchVehicle.Rating);
                    Console.WriteLine("==============================================================================");
                }
                else
                {
                    Console.WriteLine("No Vehicle Details Available");
                }

            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchVehicleByName()
        {
            try
            {
                string searchVehicleName;
                Console.WriteLine("Enter Vehicle Name to Search:");
                searchVehicleName = Console.ReadLine();
                Vehicle searchVehicle = VehicleBL.SearchVehicleByNameBL(searchVehicleName);
                if (searchVehicle != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("VehicleID\t\tVehicle Name\t\tVehicle Model\t\tDealer ID\t\tCost\t\tTotal Stock\t\tDescription\t\tRating");
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}", searchVehicle.VehicleID, searchVehicle.VehicleName, searchVehicle.VehicleModel, searchVehicle.DealerID, searchVehicle.Cost, searchVehicle.TotalStock, searchVehicle.Description, searchVehicle.Rating);
                    Console.WriteLine("==============================================================================");
                }
                else
                {
                    Console.WriteLine("No Vehicle Details Available");
                }

            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchVehicleByModel()
        {
            try
            {
                string searchVehicleModel;
                Console.WriteLine("Enter Vehicle MOdel to Search:");
                searchVehicleModel = Console.ReadLine();
                Vehicle searchVehicle = VehicleBL.SearchVehicleByNameBL(searchVehicleModel);
                if (searchVehicle != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("VehicleID\t\tVehicle Name\t\tVehicle Model\t\tDealer ID\t\tCost\t\tTotal Stock\t\tDescription\t\tRating");
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}", searchVehicle.VehicleID, searchVehicle.VehicleName, searchVehicle.VehicleModel, searchVehicle.DealerID, searchVehicle.Cost, searchVehicle.TotalStock, searchVehicle.Description, searchVehicle.Rating);
                    Console.WriteLine("==============================================================================");
                }
                else
                {
                    Console.WriteLine("No Vehicle Details Available");
                }

            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void GetAllShowroomDetails()
        {
            try
            {
                List<Showroom> showroomList = ShowroomBL.GetAllShowroomBL();
                if (showroomList != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("ShowroomID\t\tShowroom Name\t\tDealer ID\t\tOwner Name\t\tContact No.\t\tAddress\t\tCity\t\tState\t\tPincode");
                    Console.WriteLine("==============================================================================");
                    foreach (Showroom showroom in showroomList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}", showroom.ShowroomID, showroom.ShowroomName, showroom.DealerID, showroom.OwnerName,showroom.ContactNo, showroom.Address, showroom.City, showroom.State, showroom.Pincode);
                    }
                    Console.WriteLine("==============================================================================");

                }
                else
                {
                    Console.WriteLine("No Dealer Details Available");
                }
            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddShowroomData()
        {
            try
            {
                Showroom newShowroom = new Showroom();
                Console.WriteLine("Enter Showroom ID :");
                newShowroom.ShowroomID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Showroom Name :");
                newShowroom.ShowroomName = Console.ReadLine();
                Console.WriteLine("Enter Dealer ID:");
                newShowroom.DealerID =Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Owner Name:");
                newShowroom.OwnerName = Console.ReadLine();
                Console.WriteLine("Enter Contact NO. :");
                newShowroom.ContactNo = Console.ReadLine();
                Console.WriteLine("Enter Address:");
                newShowroom.Address = Console.ReadLine();
                Console.WriteLine("Enter City :");
                newShowroom.City = Console.ReadLine();
                Console.WriteLine("Enter State :");
                newShowroom.State = Console.ReadLine();
                Console.WriteLine("Enter Pincode  :");
                newShowroom.Pincode = Convert.ToInt32(Console.ReadLine());

                bool showroomAdded = ShowroomBL.AddShowroomBL(newShowroom);
                if (showroomAdded)
                    Console.WriteLine("Showroom Added");
                else
                    Console.WriteLine("Showroom not Added");
            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void GetAllSalesDetails()
        {
            try
            {
                List<Sales> salesList = SalesBL.GetAllSalesBL();
                if (salesList != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("Sales ID\t\tVehicle ID\t\tCustomer ID\t\tShowroom ID\t\tCost\t\tOrder Date\t\tDelivery Date\t\tRemarks");
                    Console.WriteLine("==============================================================================");
                    foreach (Sales sales in salesList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}", sales.SalesID, sales.VehicleID, sales.CustomerID, sales.ShowroomID, sales.Cost, sales.OrderDate, sales.DeliveryDate, sales.Remarks);
                    }
                    Console.WriteLine("==============================================================================");

                }
                else
                {
                    Console.WriteLine("No Sales Details Available");
                }
            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddSalesData()
        {
            try
            {
                Sales newSales = new Sales();
                Console.WriteLine("Enter Sales ID :");
                newSales.SalesID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Vehicle ID :");
                newSales.VehicleID = Convert.ToInt32(Console.ReadLine()); ;
                Console.WriteLine("Enter Customer ID:");
                newSales.CustomerID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Showroom ID:");
                newSales.ShowroomID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Cost :");
                newSales.Cost =Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Order Date:");
                newSales.OrderDate =Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Delivery Date :");
                newSales.DeliveryDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Remarks :");
                newSales.Remarks = Console.ReadLine();
                

                bool salesAdded = SalesBL.AddSalesBL(newSales);
                if (salesAdded)
                    Console.WriteLine("Sales Added");
                else
                    Console.WriteLine("Sales not Added");
            }
            catch (OVSRException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }




    }

}


